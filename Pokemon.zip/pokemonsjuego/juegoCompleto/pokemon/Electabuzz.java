/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pokemonsjuego.juegoCompleto.pokemon;

import java.util.Timer;
import java.util.TimerTask;
import javax.swing.JOptionPane;

/**
 *
 * @author DELL
 */
public class Electabuzz extends Pokemon {
    
    public Electabuzz() {
        nivel = 1;
        peticionComida = 5;
        contadorComida = 0;
        peticionLimpieza = 3;
        contadorLimpieza = 0;
        peticionEnfermedad = 6;
        contadorEnfermedad = 0;
    }
    
    public void recibirComida(String comida) {
        if ("Manzana".equals(comida)) {
            contadorComida = 0;
        }
        if ("Cereal".equals(comida)) {
            peticionComida = peticionComida + 2;
            contadorComida = 0;
        }
        if ("Waffle".equals(comida)) {
            peticionComida = peticionComida + 5;
            contadorComida = 0;
        }
    }
    
    public void recibirMedicina(String medicina) {
        if ("Vitamina".equals(medicina)) {
            if (contadorEnfermedad == 0) {
                contadorEnfermedad = 0;
            } else {
                contadorEnfermedad = contadorEnfermedad - 1;
            }
        }
        if ("Analgesico".equals(medicina)) {
            if (contadorEnfermedad == 0) {
                contadorEnfermedad = 0;
            } else {
                contadorEnfermedad = contadorEnfermedad - 2;
            }
        }
        if ("Antibiotico".equals(medicina)) {
            if (contadorEnfermedad == 0) {
                contadorEnfermedad = 0;
            } else {
                contadorEnfermedad = contadorEnfermedad - 3;
            }        
        }
    }
    
    public void mandarPeticionComida() {
        Timer timer = new Timer();   
        TimerTask tarea = new TimerTask() {
            @Override
            public void run() {
                if (contadorComida < peticionComida) {
                    JOptionPane.showMessageDialog(null,"Abra tiene Hambre");
                    contadorComida = contadorComida + 1;                     
                }
             }     
        };
        timer.schedule(tarea,0,120000);
    }
    
    public void mandarPeticionLimpieza() {
        Timer timer = new Timer();   
        TimerTask tarea = new TimerTask() {
            @Override
            public void run() {
                if (contadorLimpieza < peticionLimpieza) {
                    JOptionPane.showMessageDialog(null,"Abra necesita Limpieza");
                    contadorLimpieza = contadorLimpieza + 1;                     
                }
            }     
        };
        timer.schedule(tarea,0,120000);
    }
}
