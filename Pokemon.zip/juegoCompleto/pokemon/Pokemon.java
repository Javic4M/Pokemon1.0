/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pokemonsjuego.juegoCompleto.pokemon;

/**
 *
 * @author DELL
 */
public class Pokemon {
    protected int nivel;
    protected int peticionComida;
    protected int contadorComida;
    protected int peticionLimpieza;
    protected int contadorLimpieza;
    protected int peticionEnfermedad;
    protected int contadorEnfermedad;
    
    public void recibirComida(String comida) { 
    }
    
    public void recibirMedicina(String medicina) {
    }
    
    public void mandarPeticionComida() {  
    }
    
    public void mandarPeticionLimpieza() {
    }
}
