/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.pokemonsjuego.juegoCompleto.frameYPngs;

import com.mycompany.pokemonsjuego.juegoCompleto.pokemon.*;
import javax.swing.JOptionPane;

/**
 *
 * @author DELL
 */
public class ComprarComida extends javax.swing.JFrame {

    private String pokemonJugador[];
    private String pokemonRepuesto[];
    private Bulbasaur Bulbasaur;
    private Ivysaur Ivysaur;
    private Venusaur Venusaur;
    private Charmander Charmander;
    private Charmeleon Charmeleon;
    private Charizard Charizard;
    private Squirtle Squirtle;
    private Wartortle Wartortle;
    private Blastoise Blastoise;
    private Caterpie Caterpie;
    private Metapod Metapod;
    private Butterfree Butterfree;
    private Weedle Weedle;
    private Kakuna Kakuna;
    private Beedrill Beedrill;
    private Pidgey Pidgey;
    private Pidgeotto Pidgeotto;
    private Pidgeot Pidgeot;
    private Rattata Rattata;
    private Raticate Raticate;
    private Spearow Spearow;
    private Fearow Fearow;
    private Ekans Ekans;
    private Arbok Arbok;
    private Pikachu Pikachu;
    private Raichu Raichu;
    private Sandshrew Sandshrew;
    private Sandslash Sandslash;
    private Nidoran Nidoran;
    private Nidorina Nidorina;
    private Nidoqueen Nidoqueen;
    private Nidorann Nidorann;
    private Nidorino Nidorino;
    private Nidoking Nidoking;
    private Clefairy Clefairy;
    private Clefable Clefable;
    private Vulpix Vulpix;
    private Ninetales Ninetales;
    private Jigglypuff Jigglypuff;
    private Wigglytuff Wigglytuff;
    private Zubat Zubat;
    private Golbat Golbat;
    private Oddish Oddish;
    private Gloom Gloom;
    private Vileplume Vileplume;
    private Paras Paras;
    private Parasect Parasect;
    private Venonat Venonat;
    private Venomoth Venomoth;
    private Diglett Diglett;
    private Dugtrio Dugtrio;
    private Meowth Meowth;
    private Persian Persian;
    private Psyduck Psyduck;
    private Golduck Golduck;
    private Mankey Mankey;
    private Primeape Primeape;
    private Growlithe Growlithe;
    private Arcanine Arcanine;
    private Poliwag Poliwag;
    private Poliwhirl Poliwhirl;
    private Poliwrath Poliwrath;
    private Abra Abra;
    private Kadabra Kadabra;
    private Alakazam Alakazam;
    private Machop Machop;
    private Machoke Machoke;
    private Machamp Machamp;
    private Bellsprout Bellsprout;
    private Weepinbell Weepinbell;
    private Victreebel Victreebel;
    private Tentacool Tentacool;
    private Tentacruel Tentacruel;
    private Geodude Geodude;
    private Graveler Graveler;
    private Golem Golem;
    private Ponyta Ponyta;
    private Rapidash Rapidash;
    private Slowpoke Slowpoke;
    private Slowbro Slowbro;
    private Magnemite Magnemite;
    private Magneton Magneton;
    private Farfetchd Farfetchd;
    private Doduo Doduo;
    private Dodrio Dodrio;
    private Seel Seel;
    private Dewgong Dewgong;
    private Grimer Grimer;
    private Muk Muk;
    private Shellder Shellder;
    private Cloyster Cloyster;
    private Gastly Gastly;
    private Haunter Haunter;
    private Gengar Gengar;
    private Onix Onix;
    private Drowzee Drowzee;
    private Hypno Hypno;
    private Krabby Krabby;
    private Kingler Kingler;
    private Voltorb Voltorb;
    private Electrode Electrode;
    private Exeggcute Exeggcute;
    private Exeggutor Exeggutor;
    private Cubone Cubone;
    private Marowak Marowak;
    private Hitmonlee Hitmonlee;
    private Hitmonchan Hitmonchan;
    private Lickitung Lickitung;
    private Koffing Koffing;
    private Weezing Weezing;
    private Rhyhorn Rhyhorn;
    private Rhydon Rhydon;
    private Chansey Chansey;
    private Tangela Tangela;
    private Kangaskhan Kangaskhan;
    private Horsea Horsea;
    private Seadra Seadra;
    private Goldeen Goldeen;
    private Seaking Seaking;
    private Staryu Staryu;
    private Starmie Starmie;
    private MrMime MrMime;
    private Scyther Scyther;
    private Jynx Jynx;
    private Electabuzz Electabuzz;
    private Magmar Magmar;
    private Pinsir Pinsir;
    private Tauros Tauros;
    private Magikarp Magikarp;
    private Gyarados Gyarados;
    private Lapras Lapras;
    private Ditto Ditto;
    private Eevee Eevee;
    private Vaporeon Vaporeon;
    private Jolteon Jolteon;
    private Flareon Flareon;
    private Porygon Porygon;
    private Omanyte Omanyte;
    private Omastar Omastar;
    private Kabuto Kabuto;
    private Kabutops Kabutops;
    private Aerodactyl Aerodactyl;
    private Snorlax Snorlax;
    private Articuno Articuno;
    private Zapdos Zapdos;
    private Moltres Moltres;
    private Dratini Dratini;
    private Dragonair Dragonair;
    private Dragonite Dragonite;
    private Mewtwo Mewtwo;
    private Mew Mew;
    private int dinero;    
    private String comida = null;
    private String pokemon = null;
    
    /**
     * Creates new form ComprarComida
     */
    public ComprarComida(int dinero, String pokemonJugador[], String pokemonRepuesto[]) {
        initComponents();
        this.dinero = dinero;
        this.pokemonJugador = pokemonJugador;
        this.pokemonRepuesto = pokemonRepuesto;
        Bulbasaur = new Bulbasaur();
        Ivysaur = new Ivysaur();
        Venusaur = new Venusaur();
        Charmander = new Charmander();
        Charmeleon = new Charmeleon();
        Charizard = new Charizard();
        Squirtle = new Squirtle();
        Wartortle = new Wartortle();
        Blastoise = new Blastoise();
        Caterpie = new Caterpie();
        Metapod = new Metapod();
        Butterfree = new Butterfree();
        Weedle = new Weedle();
        Kakuna = new Kakuna();
        Beedrill = new Beedrill();
        Pidgey = new Pidgey();
        Pidgeotto = new Pidgeotto();
        Pidgeot = new Pidgeot();
        Rattata = new Rattata();
        Raticate = new Raticate();
        Spearow = new Spearow();
        Fearow = new Fearow();
        Ekans = new Ekans();
        Arbok = new Arbok();
        Pikachu = new Pikachu();
        Raichu = new Raichu();
        Sandshrew = new Sandshrew();
        Sandslash = new Sandslash();
        Nidoran = new Nidoran();
        Nidoqueen = new Nidoqueen();
        Nidorann = new Nidorann();
        Nidorino = new Nidorino();
        Nidoking = new Nidoking();
        Clefairy = new Clefairy();
        Clefable = new Clefable();
        Vulpix = new Vulpix();
        Ninetales = new Ninetales();
        Jigglypuff = new Jigglypuff();
        Wigglytuff = new Wigglytuff();
        Zubat = new Zubat();
        Golbat = new Golbat();
        Oddish = new Oddish();
        Gloom = new Gloom();
        Vileplume = new Vileplume();
        Paras = new Paras();
        Parasect = new Parasect();
        Venonat = new Venonat();
        Venomoth = new Venomoth();
        Diglett = new Diglett();
        Dugtrio = new Dugtrio();
        Meowth = new Meowth();
        Persian = new Persian();
        Psyduck = new Psyduck();
        Golduck = new Golduck();
        Mankey = new Mankey();
        Primeape = new Primeape();
        Growlithe = new Growlithe();
        Arcanine = new Arcanine();
        Poliwag = new Poliwag();
        Poliwhirl = new Poliwhirl();
        Poliwrath = new Poliwrath();
        Abra = new Abra();
        Kadabra = new Kadabra();
        Alakazam = new Alakazam();
        Machop = new Machop();
        Machoke = new Machoke();
        Machamp = new Machamp();
        Bellsprout = new Bellsprout();
        Weepinbell = new Weepinbell();
        Victreebel = new Victreebel();
        Tentacool = new Tentacool();
        Tentacruel = new Tentacruel();
        Geodude = new Geodude();
        Graveler = new Graveler();
        Golem = new Golem();
        Ponyta = new Ponyta();
        Rapidash = new Rapidash();
        Slowpoke = new Slowpoke();
        Slowbro = new Slowbro();
        Magnemite = new Magnemite();
        Magneton = new Magneton();
        Farfetchd = new Farfetchd();
        Doduo = new Doduo();
        Dodrio = new Dodrio();
        Seel = new Seel();
        Dewgong = new Dewgong();
        Grimer = new Grimer();
        Muk = new Muk();
        Shellder = new Shellder();
        Cloyster = new Cloyster();
        Gastly = new Gastly();
        Haunter = new Haunter();
        Gengar = new Gengar();
        Onix = new Onix();
        Drowzee = new Drowzee();
        Hypno = new Hypno();
        Krabby = new Krabby();
        Kingler = new Kingler();
        Voltorb = new Voltorb();        
        Electrode = new Electrode();
        Exeggcute = new Exeggcute();
        Exeggutor = new Exeggutor();
        Cubone = new Cubone();
        Marowak = new Marowak();
        Hitmonlee = new Hitmonlee();
        Hitmonchan = new Hitmonchan();
        Lickitung = new Lickitung();
        Koffing = new Koffing();
        Weezing = new Weezing();
        Rhyhorn = new Rhyhorn();
        Rhydon = new Rhydon();
        Chansey = new Chansey();
        Tangela = new Tangela();
        Kangaskhan = new Kangaskhan();
        Horsea = new Horsea();
        Seadra = new Seadra();
        Goldeen = new Goldeen();
        Seaking = new Seaking();
        Staryu = new Staryu();
        Starmie = new Starmie();
        MrMime = new MrMime();
        Scyther = new Scyther();
        Jynx = new Jynx();
        Electabuzz = new Electabuzz();
        Magmar = new Magmar();     
        Pinsir = new Pinsir();
        Tauros = new Tauros();
        Magikarp = new Magikarp();
        Gyarados = new Gyarados();
        Lapras = new Lapras();
        Ditto = new Ditto();
        Eevee = new Eevee();
        Vaporeon = new Vaporeon();
        Jolteon = new Jolteon();
        Flareon = new Flareon();
        Porygon = new Porygon();
        Omanyte = new Omanyte();
        Omastar = new Omastar();
        Kabuto = new Kabuto();
        Kabutops = new Kabutops();
        Aerodactyl = new Aerodactyl();   
        Snorlax = new Snorlax();
        Articuno = new Articuno();
        Zapdos = new Zapdos();
        Moltres = new Moltres();
        Dratini = new Dratini();
        Dragonair = new Dragonair();
        Dragonite = new Dragonite();
        Mewtwo = new Mewtwo();
        Mew = new Mew();
        NumeroPokemon.setVisible(false);
        Alimentar.setVisible(false);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel4 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        Numero = new javax.swing.JTextField();
        Comprar = new javax.swing.JButton();
        PreguntarQuePokemon = new javax.swing.JLabel();
        NumeroPokemon = new javax.swing.JTextField();
        Alimentar = new javax.swing.JButton();

        jLabel4.setText("jLabel4");

        jLabel1.setFont(new java.awt.Font("Rockwell", 3, 18)); // NOI18N
        jLabel1.setText("Restaurante");

        jLabel2.setText("Escriba el número del alimento que desea comprar");

        jLabel3.setText("1) Manzana con un precio de 10 monedas");

        jLabel5.setText("2) Cereal con un precio de 30 monedas");

        jLabel6.setText("3)  Waffle con un precio de 50 monedas");

        Comprar.setText("Comprar");
        Comprar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComprarActionPerformed(evt);
            }
        });

        Alimentar.setText("Alimentar");
        Alimentar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AlimentarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(74, 74, 74)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(jLabel3)
                    .addComponent(jLabel6))
                .addContainerGap(96, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                            .addComponent(jLabel1)
                            .addGap(137, 137, 137))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(Alimentar)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(NumeroPokemon, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(Numero, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(Comprar))
                                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 306, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGap(36, 36, 36)))
                    .addComponent(PreguntarQuePokemon, javax.swing.GroupLayout.PREFERRED_SIZE, 279, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel6)
                .addGap(18, 18, 18)
                .addComponent(Numero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(4, 4, 4)
                .addComponent(Comprar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(PreguntarQuePokemon, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(NumeroPokemon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Alimentar)
                .addContainerGap(37, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ComprarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComprarActionPerformed
        if (dinero >= 10) {             
            if (dinero >= 50) {
                if (obtenerNumero() > 0 && obtenerNumero() < 4) {
                    if (obtenerNumero() == 1) {
                        comida = "Manzana";
                        dinero = dinero - 10;
                    } 
                    if (obtenerNumero() == 2) {
                        comida = "Cereal";
                        dinero = dinero - 30;
                    } 
                    if (obtenerNumero() == 3) {
                        comida = "Waffle";
                        dinero = dinero - 50;
                    } 
                    PreguntarQuePokemon.setText("Escriba el número del Pokemon que desea alimentar:");
                    Numero.setEnabled(false);
                    Comprar.setEnabled(false);
                    NumeroPokemon.setVisible(true);
                    Alimentar.setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(this,"Número Incorrecto","Error",JOptionPane.ERROR_MESSAGE);
                }                 
            }
            if (dinero >= 30 && dinero < 50) {
                if (obtenerNumero() > 0 && obtenerNumero() < 4) {
                    if (obtenerNumero() == 1) {
                        comida = "Manzana";
                        dinero = dinero - 10;
                        PreguntarQuePokemon.setText("Escriba el número del Pokemon que desea alimentar:");
                        Numero.setEnabled(false);
                        Comprar.setEnabled(false);
                        NumeroPokemon.setVisible(true);
                        Alimentar.setVisible(true);
                    } 
                    if (obtenerNumero() == 2) {
                        comida = "Cereal";
                        dinero = dinero - 30;
                        PreguntarQuePokemon.setText("Escriba el número del Pokemon que desea alimentar:");
                        Numero.setEnabled(false);
                        Comprar.setEnabled(false);
                        NumeroPokemon.setVisible(true);
                        Alimentar.setVisible(true);
                    } 
                    if (obtenerNumero() == 3) {
                        JOptionPane.showMessageDialog(this,"No tienes suficiente dinero para comprar Waffles","Falta de Dinero",JOptionPane.INFORMATION_MESSAGE);
                    } 
                } else {
                    JOptionPane.showMessageDialog(this,"Número Incorrecto","Error",JOptionPane.ERROR_MESSAGE);
                }                 
            }
            if (dinero >= 10 && dinero < 30) {
                if (obtenerNumero() > 0 && obtenerNumero() < 4) {
                    if (obtenerNumero() == 1) {
                        comida = "Manzana";
                        dinero = dinero - 10;
                        PreguntarQuePokemon.setText("Escriba el número del Pokemon que desea alimentar:");
                        Numero.setEnabled(false);
                        Comprar.setEnabled(false);
                        NumeroPokemon.setVisible(true);
                        Alimentar.setVisible(true);
                    } 
                    if (obtenerNumero() == 2) {
                        JOptionPane.showMessageDialog(this,"No tienes suficiente dinero para comprar Cereal","Falta de Dinero",JOptionPane.INFORMATION_MESSAGE);
                    } 
                    if (obtenerNumero() == 3) {
                        JOptionPane.showMessageDialog(this,"No tienes suficiente dinero para comprar Waffles","Falta de Dinero",JOptionPane.INFORMATION_MESSAGE);
                    } 
                } else {
                    JOptionPane.showMessageDialog(this,"Número Incorrecto","Error",JOptionPane.ERROR_MESSAGE);
                }                  
            }         
        } else {
            JOptionPane.showMessageDialog(this,"No tienes suficiente dinero para Comprar","Error",JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_ComprarActionPerformed

    private void AlimentarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AlimentarActionPerformed
        if (obtenerNumeroPokemon() > 0 && obtenerNumeroPokemon() < 11) {
            if (obtenerNumeroPokemon() == 1) {
                pokemon = pokemonRepuesto[0];
                JOptionPane.showMessageDialog(this,pokemonJugador[0] + " fue Alimentado","Comida",JOptionPane.INFORMATION_MESSAGE);
            }
            if (obtenerNumeroPokemon() == 2) {
                pokemon = pokemonRepuesto[1];
                JOptionPane.showMessageDialog(this,pokemonJugador[1] + " fue Alimentado","Comida",JOptionPane.INFORMATION_MESSAGE);
            }
            if (obtenerNumeroPokemon() == 3) {
                pokemon = pokemonRepuesto[2];
                JOptionPane.showMessageDialog(this,pokemonJugador[2] + " fue Alimentado","Comida",JOptionPane.INFORMATION_MESSAGE);
            }
            if (obtenerNumeroPokemon() == 4) {
                pokemon = pokemonRepuesto[3];
                JOptionPane.showMessageDialog(this,pokemonJugador[3] + " fue Alimentado","Comida",JOptionPane.INFORMATION_MESSAGE);
            }
            if (obtenerNumeroPokemon() == 5) {
                pokemon = pokemonRepuesto[4];
                JOptionPane.showMessageDialog(this,pokemonJugador[4] + " fue Alimentado","Comida",JOptionPane.INFORMATION_MESSAGE);
            }
            if (obtenerNumeroPokemon() == 6) {
                pokemon = pokemonRepuesto[5];
                JOptionPane.showMessageDialog(this,pokemonJugador[5] + " fue Alimentado","Comida",JOptionPane.INFORMATION_MESSAGE);
            }
            if (obtenerNumeroPokemon() == 7) {
                pokemon = pokemonRepuesto[6];
                JOptionPane.showMessageDialog(this,pokemonJugador[6] + " fue Alimentado","Comida",JOptionPane.INFORMATION_MESSAGE);
            }
            if (obtenerNumeroPokemon() == 8) {
                pokemon = pokemonRepuesto[7];
                JOptionPane.showMessageDialog(this,pokemonJugador[7] + " fue Alimentado","Comida",JOptionPane.INFORMATION_MESSAGE);
            }
            if (obtenerNumeroPokemon() == 9) {
                pokemon = pokemonRepuesto[8];
                JOptionPane.showMessageDialog(this,pokemonJugador[8] + " fue Alimentado","Comida",JOptionPane.INFORMATION_MESSAGE);
            }
            if (obtenerNumeroPokemon() == 10) {
                pokemon = pokemonRepuesto[9];
                JOptionPane.showMessageDialog(this,pokemonJugador[9] + " fue Alimentado","Comida",JOptionPane.INFORMATION_MESSAGE);
            }
            enviarComida();
        } else {
            JOptionPane.showMessageDialog(this,"Número Incorrecto","Error",JOptionPane.ERROR_MESSAGE);
        }
        this.dispose();
    }//GEN-LAST:event_AlimentarActionPerformed

    private void enviarComida() {
        if ("Bulbasaur".equals(pokemon)) {
            Bulbasaur.recibirComida(comida);
        }
        if ("Ivysaur".equals(pokemon)) {
            Ivysaur.recibirComida(comida);
        }
        if ("Venusaur".equals(pokemon)) {
            Venusaur.recibirComida(comida);
        }
        if ("Charmander".equals(pokemon)) {
            Charmander.recibirComida(comida);
        }
        if ("Charmeleon".equals(pokemon)) {
            Charmeleon.recibirComida(comida);
        }
        if ("Charizard".equals(pokemon)) {
            Charizard.recibirComida(comida);
        }
        if ("Squirtle".equals(pokemon)) {
            Squirtle.recibirComida(comida);
        }
        if ("Wartortle".equals(pokemon)) {
            Wartortle.recibirComida(comida);
        }
        if ("Blastoise".equals(pokemon)) {
            Blastoise.recibirComida(comida);
        }
        if ("Caterpie".equals(pokemon)) {
            Caterpie.recibirComida(comida);
        }
        if ("Metapod".equals(pokemon)) {
            Metapod.recibirComida(comida);
        }
        if ("Butterfreee".equals(pokemon)) {
            Butterfree.recibirComida(comida);
        }
        if ("Weedle".equals(pokemon)) {
            Weedle.recibirComida(comida);
        }
        if ("Kakuna".equals(pokemon)) {
            Kakuna.recibirComida(comida);
        }
        if ("Beedrill".equals(pokemon)) {
            Beedrill.recibirComida(comida);
        }
        if ("Pidgey".equals(pokemon)) {
            Pidgey.recibirComida(comida);
        }
        if ("Pidgeotto".equals(pokemon)) {
            Pidgeotto.recibirComida(comida);
        }
        if ("Pidgeot".equals(pokemon)) {
            Pidgeot.recibirComida(comida);
        }
        if ("Rattata".equals(pokemon)) {
            Rattata.recibirComida(comida);
        }
        if ("Raticate".equals(pokemon)) {
            Raticate.recibirComida(comida);
        }
        if ("Spearow".equals(pokemon)) {
            Spearow.recibirComida(comida);
        }
        if ("Fearow".equals(pokemon)) {
            Fearow.recibirComida(comida);
        }
        if ("Ekans".equals(pokemon)) {
            Ekans.recibirComida(comida);
        }
        if ("Arbok".equals(pokemon)) {
            Arbok.recibirComida(comida);
        }
        if ("Pikachu".equals(pokemon)) {
            Pikachu.recibirComida(comida);
        }
        if ("Raichu".equals(pokemon)) {
            Raichu.recibirComida(comida);
        }
        if ("Sandshrew".equals(pokemon)) {
            Sandshrew.recibirComida(comida);
        }
        if ("Sandslash".equals(pokemon)) {
            Sandslash.recibirComida(comida);
        }
        if ("Nidoran".equals(pokemon)) {
            Nidoran.recibirComida(comida);
        }
        if ("Nidorina".equals(pokemon)) {
            Nidorina.recibirComida(comida);
        }
        if ("Nidoqueen".equals(pokemon)) {
            Nidoqueen.recibirComida(comida);
        }
        if ("Nidorann".equals(pokemon)) {
            Nidorann.recibirComida(comida);
        }
        if ("Nidorino".equals(pokemon)) {
            Nidorino.recibirComida(comida);
        }
        if ("Nidoking".equals(pokemon)) {
            Nidoking.recibirComida(comida);
        }
        if ("Clefairy".equals(pokemon)) {
            Clefairy.recibirComida(comida);
        }
        if ("Clefable".equals(pokemon)) {
            Clefable.recibirComida(comida);
        }
        if ("Vulpix".equals(pokemon)) {
            Vulpix.recibirComida(comida);
        }
        if ("Ninetales".equals(pokemon)) {
            Ninetales.recibirComida(comida);
        }
        if ("Jigglypuff".equals(pokemon)) {
            Jigglypuff.recibirComida(comida);
        }
        if ("Wigglytuff".equals(pokemon)) {
            Wigglytuff.recibirComida(comida);
        }
        if ("Zubat".equals(pokemon)) {
            Zubat.recibirComida(comida);
        }
        if ("Golbat".equals(pokemon)) {
            Golbat.recibirComida(comida);
        }
        if ("Oddish".equals(pokemon)) {
            Oddish.recibirComida(comida);
        }
        if ("Gloom".equals(pokemon)) {
            Gloom.recibirComida(comida);
        }
        if ("Vileplume".equals(pokemon)) {
            Vileplume.recibirComida(comida);
        }
        if ("Paras".equals(pokemon)) {
            Paras.recibirComida(comida);
        }
        if ("Paracect".equals(pokemon)) {
            Parasect.recibirComida(comida);
        }
        if ("Venonat".equals(pokemon)) {
            Venonat.recibirComida(comida);
        }
        if ("Venomoth".equals(pokemon)) {
            Venomoth.recibirComida(comida);
        }
        if ("Diglett".equals(pokemon)) {
            Diglett.recibirComida(comida);
        }
        if ("Dugtrio".equals(pokemon)) {
            Dugtrio.recibirComida(comida);
        }
        if ("Meowth".equals(pokemon)) {
            Meowth.recibirComida(comida);
        }
        if ("Persian".equals(pokemon)) {
            Persian.recibirComida(comida);
        }
        if ("Psyduck".equals(pokemon)) {
            Psyduck.recibirComida(comida);
        }
        if ("Golduck".equals(pokemon)) {
            Golduck.recibirComida(comida);
        }
        if ("Mankey".equals(pokemon)) {
            Mankey.recibirComida(comida);
        }
        if ("Primeape".equals(pokemon)) {
            Primeape.recibirComida(comida);
        }
        if ("Growlithe".equals(pokemon)) {
            Growlithe.recibirComida(comida);
        }
        if ("Arcanine".equals(pokemon)) {
            Arcanine.recibirComida(comida);
        }
        if ("Poliwag".equals(pokemon)) {
            Poliwag.recibirComida(comida);
        }
        if ("Poliwhirl".equals(pokemon)) {
            Poliwhirl.recibirComida(comida);
        }
        if ("Poliwrath".equals(pokemon)) {
            Poliwrath.recibirComida(comida);
        }
        if ("Abra".equals(pokemon)) {
            Abra.recibirComida(comida);
        }
        if ("Kadabra".equals(pokemon)) {
            Kadabra.recibirComida(comida);
        }
        if ("Alakazam".equals(pokemon)) {
            Alakazam.recibirComida(comida);
        }
        if ("Machop".equals(pokemon)) {
            Machop.recibirComida(comida);
        }
        if ("Machoke".equals(pokemon)) {
            Machoke.recibirComida(comida);
        }
        if ("Machamp".equals(pokemon)) {
            Machamp.recibirComida(comida);
        }
        if ("Bellsprout".equals(pokemon)) {
            Bellsprout.recibirComida(comida);
        }
        if ("Weepinbell".equals(pokemon)) {
            Weepinbell.recibirComida(comida);
        }
        if ("Victreebel".equals(pokemon)) {
            Victreebel.recibirComida(comida);
        }
        if ("Tentacool".equals(pokemon)) {
            Tentacool.recibirComida(comida);
        }
        if ("Tentacruel".equals(pokemon)) {
            Tentacruel.recibirComida(comida);
        }
        if ("Geodude".equals(pokemon)) {
            Geodude.recibirComida(comida);
        }
        if ("Graveler".equals(pokemon)) {
            Graveler.recibirComida(comida);
        }
        if ("Golem".equals(pokemon)) {
            Golem.recibirComida(comida);
        }
        if ("Ponyta".equals(pokemon)) {
            Ponyta.recibirComida(comida);
        }
        if ("Rapidash".equals(pokemon)) {
            Rapidash.recibirComida(comida);
        }
        if ("Slowpoke".equals(pokemon)) {
            Slowpoke.recibirComida(comida);
        }
        if ("Slowbro".equals(pokemon)) {
            Slowbro.recibirComida(comida);
        }
        if ("Magnemite".equals(pokemon)) {
            Magnemite.recibirComida(comida);
        }
        if ("Magneton".equals(pokemon)) {
            Magneton.recibirComida(comida);
        }
        if ("Farfetchd".equals(pokemon)) {
            Farfetchd.recibirComida(comida);
        }
        if ("Doduo".equals(pokemon)) {
            Doduo.recibirComida(comida);
        }
        if ("Dodrio".equals(pokemon)) {
            Dodrio.recibirComida(comida);
        }
        if ("Seel".equals(pokemon)) {
            Seel.recibirComida(comida);
        }
        if ("Dewgong".equals(pokemon)) {
            Dewgong.recibirComida(comida);
        }
        if ("Grimer".equals(pokemon)) {
            Grimer.recibirComida(comida);
        }
        if ("Muk".equals(pokemon)) {
            Muk.recibirComida(comida);
        }
        if ("Shellder".equals(pokemon)) {
            Shellder.recibirComida(comida);
        }
        if ("Cloyster".equals(pokemon)) {
            Cloyster.recibirComida(comida);
        }
        if ("Gastly".equals(pokemon)) {
            Gastly.recibirComida(comida);
        }
        if ("Haunter".equals(pokemon)) {
            Haunter.recibirComida(comida);
        }
        if ("Gengar".equals(pokemon)) {
            Gengar.recibirComida(comida);
        }
        if ("Onix".equals(pokemon)) {
            Onix.recibirComida(comida);
        }
        if ("Drowzee".equals(pokemon)) {
            Drowzee.recibirComida(comida);
        }
        if ("Hypno".equals(pokemon)) {
            Hypno.recibirComida(comida);
        }
        if ("Krabby".equals(pokemon)) {
            Krabby.recibirComida(comida);
        }
        if ("Kingler".equals(pokemon)) {
            Kingler.recibirComida(comida);
        }
        if ("Voltorb".equals(pokemon)) {
            Voltorb.recibirComida(comida);
        }
        if ("Electrode".equals(pokemon)) {
            Electrode.recibirComida(comida);
        }
        if ("Exeggcute".equals(pokemon)) {
            Exeggcute.recibirComida(comida);
        }
        if ("Exeggutor".equals(pokemon)) {
            Exeggutor.recibirComida(comida);
        }
        if ("Cubone".equals(pokemon)) {
            Cubone.recibirComida(comida);
        }
        if ("Marowark".equals(pokemon)) {
            Marowak.recibirComida(comida);
        }
        if ("Hitmonlee".equals(pokemon)) {
            Hitmonlee.recibirComida(comida);
        }
        if ("Hitmonchan".equals(pokemon)) {
            Hitmonchan.recibirComida(comida);
        }
        if ("Lickitung".equals(pokemon)) {
            Lickitung.recibirComida(comida);
        }
        if ("Koffing".equals(pokemon)) {
            Koffing.recibirComida(comida);
        }
        if ("Weezing".equals(pokemon)) {
            Weezing.recibirComida(comida);
        }
        if ("Rhyhorn".equals(pokemon)) {
            Rhyhorn.recibirComida(comida);
        }
        if ("Rhydon".equals(pokemon)) {
            Rhydon.recibirComida(comida);
        }
        if ("Chansey".equals(pokemon)) {
            Chansey.recibirComida(comida);
        }
        if ("Tangela".equals(pokemon)) {
            Tangela.recibirComida(comida);
        }
        if ("Kangaskhan".equals(pokemon)) {
            Kangaskhan.recibirComida(comida);
        }
        if ("Horsea".equals(pokemon)) {
            Horsea.recibirComida(comida);
        }
        if ("Seadra".equals(pokemon)) {
            Seadra.recibirComida(comida);
        }
        if ("Goldeen".equals(pokemon)) {
            Goldeen.recibirComida(comida);
        }
        if ("Seaking".equals(pokemon)) {
            Seaking.recibirComida(comida);
        }
        if ("Staryu".equals(pokemon)) {
            Staryu.recibirComida(comida);
        }
        if ("Starmie".equals(pokemon)) {
            Starmie.recibirComida(comida);
        }
        if ("MrMime".equals(pokemon)) {
            MrMime.recibirComida(comida);
        }
        if ("Scyther".equals(pokemon)) {
            Scyther.recibirComida(comida);
        }
        if ("Jynx".equals(pokemon)) {
            Jynx.recibirComida(comida);
        }
        if ("Electabuzz".equals(pokemon)) {
            Electabuzz.recibirComida(comida);
        }
        if ("Magmar".equals(pokemon)) {
            Magmar.recibirComida(comida);
        }
        if ("Pinsir".equals(pokemon)) {
            Pinsir.recibirComida(comida);
        }
        if ("Tauros".equals(pokemon)) {
            Tauros.recibirComida(comida);
        }
        if ("Magikarp".equals(pokemon)) {
            Magikarp.recibirComida(comida);
        }
        if ("Gyarados".equals(pokemon)) {
            Gyarados.recibirComida(comida);
        }
        if ("Lapras".equals(pokemon)) {
            Lapras.recibirComida(comida);
        }
        if ("Ditto".equals(pokemon)) {
            Ditto.recibirComida(comida);
        }
        if ("Eevee".equals(pokemon)) {
            Eevee.recibirComida(comida);
        }
        if ("Vaporeon".equals(pokemon)) {
            Vaporeon.recibirComida(comida);
        }
        if ("Jolteon".equals(pokemon)) {
            Jolteon.recibirComida(comida);
        }
        if ("Flareon".equals(pokemon)) {
            Flareon.recibirComida(comida);
        }
        if ("Porygon".equals(pokemon)) {
            Porygon.recibirComida(comida);
        }
        if ("Omanyte".equals(pokemon)) {
            Omanyte.recibirComida(comida);
        }
        if ("Omastar".equals(pokemon)) {
            Omastar.recibirComida(comida);
        }
        if ("Kabuto".equals(pokemon)) {
            Kabuto.recibirComida(comida);
        }
        if ("Kabutops".equals(pokemon)) {
            Kabutops.recibirComida(comida);
        }
        if ("Aerodactyl".equals(pokemon)) {
            Aerodactyl.recibirComida(comida);
        }
        if ("Snorlax".equals(pokemon)) {
            Snorlax.recibirComida(comida);
        }
        if ("Articuno".equals(pokemon)) {
            Articuno.recibirComida(comida);
        }
        if ("Zapdos".equals(pokemon)) {
            Zapdos.recibirComida(comida);
        }
        if ("Moltres".equals(pokemon)) {
            Moltres.recibirComida(comida);
        }
        if ("Dratini".equals(pokemon)) {
            Dratini.recibirComida(comida);
        }
        if ("Dragonair".equals(pokemon)) {
            Dragonair.recibirComida(comida);
        }
        if ("Dragonite".equals(pokemon)) {
            Dragonite.recibirComida(comida);
        }
        if ("Mewtwo".equals(pokemon)) {
            Mewtwo.recibirComida(comida);
        }
        if ("Mew".equals(pokemon)) {
            Mew.recibirComida(comida);
        }
    }
    
    private int obtenerNumero() {
        return Integer.valueOf(Numero.getText());
    }
    
    private int obtenerNumeroPokemon() {
        return Integer.valueOf(NumeroPokemon.getText());
    }
    
    protected int darVuelto() {
        return dinero;
    }
    /**
     * @param args the command line arguments
     */

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Alimentar;
    private javax.swing.JButton Comprar;
    private javax.swing.JTextField Numero;
    private javax.swing.JTextField NumeroPokemon;
    private javax.swing.JLabel PreguntarQuePokemon;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    // End of variables declaration//GEN-END:variables
}
