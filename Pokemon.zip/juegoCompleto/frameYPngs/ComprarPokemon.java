/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.pokemonsjuego.juegoCompleto.frameYPngs;

import com.mycompany.pokemonsjuego.juegoCompleto.pokemon.*;
import javax.swing.JOptionPane;
/**
 *
 * @author DELL
 */
public class ComprarPokemon extends javax.swing.JFrame {

    private Bulbasaur Bulbasaur;
    private Ivysaur Ivysaur;
    private Venusaur Venusaur;
    private Charmander Charmander;
    private Charmeleon Charmeleon;
    private Charizard Charizard;
    private Squirtle Squirtle;
    private Wartortle Wartortle;
    private Blastoise Blastoise;
    private Caterpie Caterpie;
    private Metapod Metapod;
    private Butterfree Butterfree;
    private Weedle Weedle;
    private Kakuna Kakuna;
    private Beedrill Beedrill;
    private Pidgey Pidgey;
    private Pidgeotto Pidgeotto;
    private Pidgeot Pidgeot;
    private Rattata Rattata;
    private Raticate Raticate;
    private Spearow Spearow;
    private Fearow Fearow;
    private Ekans Ekans;
    private Arbok Arbok;
    private Pikachu Pikachu;
    private Raichu Raichu;
    private Sandshrew Sandshrew;
    private Sandslash Sandslash;
    private Nidoran Nidoran;
    private Nidorina Nidorina;
    private Nidoqueen Nidoqueen;
    private Nidorann Nidorann;
    private Nidorino Nidorino;
    private Nidoking Nidoking;
    private Clefairy Clefairy;
    private Clefable Clefable;
    private Vulpix Vulpix;
    private Ninetales Ninetales;
    private Jigglypuff Jigglypuff;
    private Wigglytuff Wigglytuff;
    private Zubat Zubat;
    private Golbat Golbat;
    private Oddish Oddish;
    private Gloom Gloom;
    private Vileplume Vileplume;
    private Paras Paras;
    private Parasect Parasect;
    private Venonat Venonat;
    private Venomoth Venomoth;
    private Diglett Diglett;
    private Dugtrio Dugtrio;
    private Meowth Meowth;
    private Persian Persian;
    private Psyduck Psyduck;
    private Golduck Golduck;
    private Mankey Mankey;
    private Primeape Primeape;
    private Growlithe Growlithe;
    private Arcanine Arcanine;
    private Poliwag Poliwag;
    private Poliwhirl Poliwhirl;
    private Poliwrath Poliwrath;
    private Abra Abra;
    private Kadabra Kadabra;
    private Alakazam Alakazam;
    private Machop Machop;
    private Machoke Machoke;
    private Machamp Machamp;
    private Bellsprout Bellsprout;
    private Weepinbell Weepinbell;
    private Victreebel Victreebel;
    private Tentacool Tentacool;
    private Tentacruel Tentacruel;
    private Geodude Geodude;
    private Graveler Graveler;
    private Golem Golem;
    private Ponyta Ponyta;
    private Rapidash Rapidash;
    private Slowpoke Slowpoke;
    private Slowbro Slowbro;
    private Magnemite Magnemite;
    private Magneton Magneton;
    private Farfetchd Farfetchd;
    private Doduo Doduo;
    private Dodrio Dodrio;
    private Seel Seel;
    private Dewgong Dewgong;
    private Grimer Grimer;
    private Muk Muk;
    private Shellder Shellder;
    private Cloyster Cloyster;
    private Gastly Gastly;
    private Haunter Haunter;
    private Gengar Gengar;
    private Onix Onix;
    private Drowzee Drowzee;
    private Hypno Hypno;
    private Krabby Krabby;
    private Kingler Kingler;
    private Voltorb Voltorb;
    private Electrode Electrode;
    private Exeggcute Exeggcute;
    private Exeggutor Exeggutor;
    private Cubone Cubone;
    private Marowak Marowak;
    private Hitmonlee Hitmonlee;
    private Hitmonchan Hitmonchan;
    private Lickitung Lickitung;
    private Koffing Koffing;
    private Weezing Weezing;
    private Rhyhorn Rhyhorn;
    private Rhydon Rhydon;
    private Chansey Chansey;
    private Tangela Tangela;
    private Kangaskhan Kangaskhan;
    private Horsea Horsea;
    private Seadra Seadra;
    private Goldeen Goldeen;
    private Seaking Seaking;
    private Staryu Staryu;
    private Starmie Starmie;
    private MrMime MrMime;
    private Scyther Scyther;
    private Jynx Jynx;
    private Electabuzz Electabuzz;
    private Magmar Magmar;
    private Pinsir Pinsir;
    private Tauros Tauros;
    private Magikarp Magikarp;
    private Gyarados Gyarados;
    private Lapras Lapras;
    private Ditto Ditto;
    private Eevee Eevee;
    private Vaporeon Vaporeon;
    private Jolteon Jolteon;
    private Flareon Flareon;
    private Porygon Porygon;
    private Omanyte Omanyte;
    private Omastar Omastar;
    private Kabuto Kabuto;
    private Kabutops Kabutops;
    private Aerodactyl Aerodactyl;
    private Snorlax Snorlax;
    private Articuno Articuno;
    private Zapdos Zapdos;
    private Moltres Moltres;
    private Dratini Dratini;
    private Dragonair Dragonair;
    private Dragonite Dragonite;
    private Mewtwo Mewtwo;
    private Mew Mew;
    private String pokemonJugador[];
    private String pokemonRepuesto[];
    private int dinero;
    private String pokemon = null;
    /**
     * Creates new form ComprarPokemon
     */
    public ComprarPokemon(int dinero, String pokemonJugador[], String pokemonRepuesto[]) {
        initComponents();
        this.dinero = dinero;
        this.pokemonJugador = pokemonJugador;
        this.pokemonRepuesto = pokemonRepuesto;
        Bulbasaur = new Bulbasaur();
        Ivysaur = new Ivysaur();
        Venusaur = new Venusaur();
        Charmander = new Charmander();
        Charmeleon = new Charmeleon();
        Charizard = new Charizard();
        Squirtle = new Squirtle();
        Wartortle = new Wartortle();
        Blastoise = new Blastoise();
        Caterpie = new Caterpie();
        Metapod = new Metapod();
        Butterfree = new Butterfree();
        Weedle = new Weedle();
        Kakuna = new Kakuna();
        Beedrill = new Beedrill();
        Pidgey = new Pidgey();
        Pidgeotto = new Pidgeotto();
        Pidgeot = new Pidgeot();
        Rattata = new Rattata();
        Raticate = new Raticate();
        Spearow = new Spearow();
        Fearow = new Fearow();
        Ekans = new Ekans();
        Arbok = new Arbok();
        Pikachu = new Pikachu();
        Raichu = new Raichu();
        Sandshrew = new Sandshrew();
        Sandslash = new Sandslash();
        Nidoran = new Nidoran();
        Nidoqueen = new Nidoqueen();
        Nidorann = new Nidorann();
        Nidorino = new Nidorino();
        Nidoking = new Nidoking();
        Clefairy = new Clefairy();
        Clefable = new Clefable();
        Vulpix = new Vulpix();
        Ninetales = new Ninetales();
        Jigglypuff = new Jigglypuff();
        Wigglytuff = new Wigglytuff();
        Zubat = new Zubat();
        Golbat = new Golbat();
        Oddish = new Oddish();
        Gloom = new Gloom();
        Vileplume = new Vileplume();
        Paras = new Paras();
        Parasect = new Parasect();
        Venonat = new Venonat();
        Venomoth = new Venomoth();
        Diglett = new Diglett();
        Dugtrio = new Dugtrio();
        Meowth = new Meowth();
        Persian = new Persian();
        Psyduck = new Psyduck();
        Golduck = new Golduck();
        Mankey = new Mankey();
        Primeape = new Primeape();
        Growlithe = new Growlithe();
        Arcanine = new Arcanine();
        Poliwag = new Poliwag();
        Poliwhirl = new Poliwhirl();
        Poliwrath = new Poliwrath();
        Abra = new Abra();
        Kadabra = new Kadabra();
        Alakazam = new Alakazam();
        Machop = new Machop();
        Machoke = new Machoke();
        Machamp = new Machamp();
        Bellsprout = new Bellsprout();
        Weepinbell = new Weepinbell();
        Victreebel = new Victreebel();
        Tentacool = new Tentacool();
        Tentacruel = new Tentacruel();
        Geodude = new Geodude();
        Graveler = new Graveler();
        Golem = new Golem();
        Ponyta = new Ponyta();
        Rapidash = new Rapidash();
        Slowpoke = new Slowpoke();
        Slowbro = new Slowbro();
        Magnemite = new Magnemite();
        Magneton = new Magneton();
        Farfetchd = new Farfetchd();
        Doduo = new Doduo();
        Dodrio = new Dodrio();
        Seel = new Seel();
        Dewgong = new Dewgong();
        Grimer = new Grimer();
        Muk = new Muk();
        Shellder = new Shellder();
        Cloyster = new Cloyster();
        Gastly = new Gastly();
        Haunter = new Haunter();
        Gengar = new Gengar();
        Onix = new Onix();
        Drowzee = new Drowzee();
        Hypno = new Hypno();
        Krabby = new Krabby();
        Kingler = new Kingler();
        Voltorb = new Voltorb();        
        Electrode = new Electrode();
        Exeggcute = new Exeggcute();
        Exeggutor = new Exeggutor();
        Cubone = new Cubone();
        Marowak = new Marowak();
        Hitmonlee = new Hitmonlee();
        Hitmonchan = new Hitmonchan();
        Lickitung = new Lickitung();
        Koffing = new Koffing();
        Weezing = new Weezing();
        Rhyhorn = new Rhyhorn();
        Rhydon = new Rhydon();
        Chansey = new Chansey();
        Tangela = new Tangela();
        Kangaskhan = new Kangaskhan();
        Horsea = new Horsea();
        Seadra = new Seadra();
        Goldeen = new Goldeen();
        Seaking = new Seaking();
        Staryu = new Staryu();
        Starmie = new Starmie();
        MrMime = new MrMime();
        Scyther = new Scyther();
        Jynx = new Jynx();
        Electabuzz = new Electabuzz();
        Magmar = new Magmar();     
        Pinsir = new Pinsir();
        Tauros = new Tauros();
        Magikarp = new Magikarp();
        Gyarados = new Gyarados();
        Lapras = new Lapras();
        Ditto = new Ditto();
        Eevee = new Eevee();
        Vaporeon = new Vaporeon();
        Jolteon = new Jolteon();
        Flareon = new Flareon();
        Porygon = new Porygon();
        Omanyte = new Omanyte();
        Omastar = new Omastar();
        Kabuto = new Kabuto();
        Kabutops = new Kabutops();
        Aerodactyl = new Aerodactyl();   
        Snorlax = new Snorlax();
        Articuno = new Articuno();
        Zapdos = new Zapdos();
        Moltres = new Moltres();
        Dratini = new Dratini();
        Dragonair = new Dragonair();
        Dragonite = new Dragonite();
        Mewtwo = new Mewtwo();
        Mew = new Mew();
        Si.setVisible(false);
        No.setVisible(false);
        Si2.setVisible(false);
        No2.setVisible(false);
        NuevoNombre.setVisible(false);
        Aceptar.setVisible(false);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Titulo = new javax.swing.JLabel();
        Contexto = new javax.swing.JLabel();
        Contexto1 = new javax.swing.JLabel();
        numeroDeCompra = new javax.swing.JTextField();
        comprar = new javax.swing.JButton();
        Escritura = new javax.swing.JLabel();
        Si = new javax.swing.JButton();
        No = new javax.swing.JButton();
        Pregunta = new javax.swing.JLabel();
        Si2 = new javax.swing.JButton();
        No2 = new javax.swing.JButton();
        ConsultarApodo = new javax.swing.JLabel();
        NuevoNombre = new javax.swing.JTextField();
        Aceptar = new javax.swing.JButton();

        Titulo.setFont(new java.awt.Font("Rockwell", 3, 18)); // NOI18N
        Titulo.setText("Pokemon");

        Contexto.setText("Escriba el número del pokemon que desea comprar");

        Contexto1.setText("Cada pokemon tendrá un costo de 50 monedas");

        comprar.setText("Comprar");
        comprar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comprarActionPerformed(evt);
            }
        });

        Si.setText("Si");
        Si.setDoubleBuffered(true);
        Si.setFocusable(false);
        Si.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SiActionPerformed(evt);
            }
        });

        No.setText("No");
        No.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NoActionPerformed(evt);
            }
        });

        Si2.setText("Si");
        Si2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Si2ActionPerformed(evt);
            }
        });

        No2.setText("No");
        No2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                No2ActionPerformed(evt);
            }
        });

        Aceptar.setText("Aceptar");
        Aceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AceptarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Contexto1)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(Pregunta, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                    .addComponent(numeroDeCompra, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(116, 116, 116)
                                    .addComponent(comprar))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                    .addGap(21, 21, 21)
                                    .addComponent(Si)
                                    .addGap(18, 18, 18)
                                    .addComponent(No))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                    .addGap(22, 22, 22)
                                    .addComponent(Si2)
                                    .addGap(18, 18, 18)
                                    .addComponent(No2))
                                .addComponent(Escritura, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 454, Short.MAX_VALUE))
                            .addComponent(NuevoNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Contexto)
                            .addComponent(ConsultarApodo, javax.swing.GroupLayout.PREFERRED_SIZE, 370, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(Aceptar)
                                .addGap(92, 92, 92)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(Titulo)
                        .addGap(177, 177, 177))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Titulo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Contexto)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Contexto1)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(numeroDeCompra, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(comprar))
                .addGap(18, 18, 18)
                .addComponent(Escritura, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Si)
                    .addComponent(No))
                .addGap(18, 18, 18)
                .addComponent(Pregunta, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(No2)
                    .addComponent(Si2))
                .addGap(18, 18, 18)
                .addComponent(ConsultarApodo, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(NuevoNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Aceptar)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private int obtenerNumero() {
        return Integer.valueOf(numeroDeCompra.getText());
    }
    
    private void comprarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comprarActionPerformed
        if (dinero >= 50) {     
            if (obtenerNumero() > 0 && obtenerNumero() < 152) {
                switch (obtenerNumero()) {
                    case 1 -> pokemon = "Bulbasaur";
                    case 2 -> pokemon = "Ivysaur";
                    case 3 -> pokemon = "Venusaur";
                    case 4 -> pokemon = "Charmander";
                    case 5 -> pokemon = "Charmeleon";
                    case 6 -> pokemon = "Charizard";
                    case 7 -> pokemon = "Ardilla";
                    case 8 -> pokemon = "Wartortle";
                    case 9 -> pokemon = "Blastoise";
                    case 10 -> pokemon = "Caterpie";
                    case 11 -> pokemon = "Metapod";
                    case 12 -> pokemon = "Butterfree";
                    case 13 -> pokemon = "Weedle";
                    case 14 -> pokemon = "Kakuna";
                    case 15 -> pokemon = "Beedrill";
                    case 16 -> pokemon = "Pidgey";
                    case 17 -> pokemon = "Pidgeotto";
                    case 18 -> pokemon = "Pidgeot";
                    case 19 -> pokemon = "Rattata";
                    case 20 -> pokemon = "Raticate";
                    case 21 -> pokemon = "Spearow";
                    case 22 -> pokemon = "Fearow";
                    case 23 -> pokemon = "Ekans";
                    case 24 -> pokemon = "Arbok";
                    case 25 -> pokemon = "Pikachu";
                    case 26 -> pokemon = "Raichu";
                    case 27 -> pokemon = "Sandshrew";
                    case 28 -> pokemon = "Sandslash";
                    case 29 -> pokemon = "Nidoran";
                    case 30 -> pokemon = "Nidorina";
                    case 31 -> pokemon = "Nidoqueen";
                    case 32 -> pokemon = "Nidorann";
                    case 33 -> pokemon = "Nidorino";
                    case 34 -> pokemon = "Nidoking";
                    case 35 -> pokemon = "Clefairy";
                    case 36 -> pokemon = "Clefable";
                    case 37 -> pokemon = "Vulpix";
                    case 38 -> pokemon = "Ninetales";
                    case 39 -> pokemon = "Jigglypuff";
                    case 40 -> pokemon = "Wigglytuff";
                    case 41 -> pokemon = "Zubat";
                    case 42 -> pokemon = "Golbat";
                    case 43 -> pokemon = "Oddish";
                    case 44 -> pokemon = "Gloom";
                    case 45 -> pokemon = "Vileplume";
                    case 46 -> pokemon = "Paras";
                    case 47 -> pokemon = "Parasect";
                    case 48 -> pokemon = "Venonat";
                    case 49 -> pokemon = "Venomoth";
                    case 50 -> pokemon = "Diglett";
                    case 51 -> pokemon = "Dugtrio";
                    case 52 -> pokemon = "Meowth";
                    case 53 -> pokemon = "Persian";
                    case 54 -> pokemon = "Psyduck";
                    case 55 -> pokemon = "Golduck";
                    case 56 -> pokemon = "Mankey";
                    case 57 -> pokemon = "Primeape";
                    case 58 -> pokemon = "Growlithe";
                    case 59 -> pokemon = "Growlithe";
                    case 60 -> pokemon = "Poliwag";
                    case 61 -> pokemon = "Poliwhirl";
                    case 62 -> pokemon = "Poliwrath";
                    case 63 -> pokemon = "Abra";
                    case 64 -> pokemon = "Kadabra";
                    case 65 -> pokemon = "Alakazam";
                    case 66 -> pokemon = "Machop";
                    case 67 -> pokemon = "Machoke";
                    case 68 -> pokemon = "Machamp";
                    case 69 -> pokemon = "Bellsprout";
                    case 70 -> pokemon = "Weepinbell";
                    case 71 -> pokemon = "Victreebel";
                    case 72 -> pokemon = "Tentacool";
                    case 73 -> pokemon = "Tentacruel";
                    case 74 -> pokemon = "Geodude";
                    case 75 -> pokemon = "Graveler";
                    case 76 -> pokemon = "Golem";
                    case 77 -> pokemon = "Ponyta";
                    case 78 -> pokemon = "Rapidash";
                    case 79 -> pokemon = "Slowpoke";
                    case 80 -> pokemon = "Slowbro";
                    case 81 -> pokemon = "Magnemite";
                    case 82 -> pokemon = "Magneton";
                    case 83 -> pokemon = "Farfetchd";
                    case 84 -> pokemon = "Doduo";
                    case 85 -> pokemon = "Dodrio";
                    case 86 -> pokemon = "Seel";
                    case 87 -> pokemon = "Dewgong";
                    case 88 -> pokemon = "Grimer";
                    case 89 -> pokemon = "Muk";
                    case 90 -> pokemon = "Shellder";
                    case 91 -> pokemon = "Cloyster";
                    case 92 -> pokemon = "Gastly";
                    case 93 -> pokemon = "Haunter";
                    case 94 -> pokemon = "Gengar";
                    case 95 -> pokemon = "Onix";
                    case 96 -> pokemon = "Drowzee";
                    case 97 -> pokemon = "Hypno";
                    case 98 -> pokemon = "Krabby";
                    case 99 -> pokemon = "Kingler";
                    case 100 -> pokemon = "Voltorb";
                    case 101 -> pokemon = "Electrode";
                    case 102 -> pokemon = "Exeggcute";
                    case 103 -> pokemon = "Exeggutor";
                    case 104 -> pokemon = "Cubone";
                    case 105 -> pokemon = "Marowak";
                    case 106 -> pokemon = "Hitmonlee";
                    case 107 -> pokemon = "Hitmonchan";
                    case 108 -> pokemon = "Lickitung";
                    case 109 -> pokemon = "Koffing";
                    case 110 -> pokemon = "Weezing";
                    case 111 -> pokemon = "Rhyhorn";
                    case 112 -> pokemon = "Rhydon";
                    case 113 -> pokemon = "Chansey";
                    case 114 -> pokemon = "Tangela";
                    case 115 -> pokemon = "Kangaskhan";
                    case 116 -> pokemon = "Horsea";
                    case 117 -> pokemon = "Seadra";
                    case 118 -> pokemon = "Goldeen";
                    case 119 -> pokemon = "Seaking";
                    case 120 -> pokemon = "Staryu";
                    case 121 -> pokemon = "Starmie";
                    case 122 -> pokemon = "MrMime";
                    case 123 -> pokemon = "Scyther";
                    case 124 -> pokemon = "Jynx";
                    case 125 -> pokemon = "Electabuzz";
                    case 126 -> pokemon = "Magmar";
                    case 127 -> pokemon = "Pinsir";
                    case 128 -> pokemon = "Tauros";
                    case 129 -> pokemon = "Magikarp";
                    case 130 -> pokemon = "Gyarados";
                    case 131 -> pokemon = "Lapras";
                    case 132 -> pokemon = "Ditto";
                    case 133 -> pokemon = "Eevee";
                    case 134 -> pokemon = "Vaporeon";
                    case 135 -> pokemon = "Jolteon";
                    case 136 -> pokemon = "Flareon";
                    case 137 -> pokemon = "Porygon";
                    case 138 -> pokemon = "Omanyte";
                    case 139 -> pokemon = "Omastar";
                    case 140 -> pokemon = "Kabuto";
                    case 141 -> pokemon = "Kabutops";
                    case 142 -> pokemon = "Aerodactyl";
                    case 143 -> pokemon = "Snorlax";
                    case 144 -> pokemon = "Articuno";
                    case 145 -> pokemon = "Zapdos";
                    case 146 -> pokemon = "Moltres";
                    case 147 -> pokemon = "Dratini";
                    case 148 -> pokemon = "Dragonair";
                    case 149 -> pokemon = "Dragonite";
                    case 150 -> pokemon = "Mewtwo";
                    case 151 -> pokemon = "Mew";
                    default -> {
                    }    
                } 
                if ("------".equals(pokemonJugador[9])) {
                    Escritura.setText("Esta seguro de comprar el pokémon No." + obtenerNumero() + " llamado " + pokemon + "?");
                    comprar.setEnabled(false);
                    numeroDeCompra.setEnabled(false);
                    Si.setVisible(true);
                    No.setVisible(true);                
                } else {
                    JOptionPane.showMessageDialog(this,"Ya no tienes espacio disponible en tu equipo","Error",JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(this,"Número Incorrecto","Error",JOptionPane.ERROR_MESSAGE);
            }            
        } else {
            JOptionPane.showMessageDialog(this,"No tienes suficiente dinero para Comprar","Error",JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_comprarActionPerformed

    private void SiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SiActionPerformed
        Pregunta.setText("Desea ponerle un apodo a su nuevo Pokemon?");
        No.setEnabled(false);
        Si2.setVisible(true);
        No2.setVisible(true);
        
            adquirirRepuesto();
            if ("Bulbasaur".equals(pokemon)) {
                Bulbasaur.mandarPeticionComida();
            }
            if ("Ivysaur".equals(pokemon)) {
                Ivysaur.mandarPeticionComida();
            }
            if ("Venusaur".equals(pokemon)) {
                Venusaur.mandarPeticionComida();
            }
            if ("Charmander".equals(pokemon)) {
                Charmander.mandarPeticionComida();
            }
            if ("Charmeleon".equals(pokemon)) {
                Charmeleon.mandarPeticionComida();
            }
            if ("Charizard".equals(pokemon)) {
                Charizard.mandarPeticionComida();
            }
            if ("Squirtle".equals(pokemon)) {
                Squirtle.mandarPeticionComida();
            }
            if ("Wartortle".equals(pokemon)) {
                Wartortle.mandarPeticionComida();
            }
            if ("Blastoise".equals(pokemon)) {
                Blastoise.mandarPeticionComida();
            }
            if ("Caterpie".equals(pokemon)) {
                Caterpie.mandarPeticionComida();
            }
            if ("Metapod".equals(pokemon)) {
                Metapod.mandarPeticionComida();
            }
            if ("Butterfreee".equals(pokemon)) {
                Butterfree.mandarPeticionComida();
            }
            if ("Weedle".equals(pokemon)) {
                Weedle.mandarPeticionComida();
            }
            if ("Kakuna".equals(pokemon)) {
                Kakuna.mandarPeticionComida();
            }
            if ("Beedrill".equals(pokemon)) {
                Beedrill.mandarPeticionComida();
            }
            if ("Pidgey".equals(pokemon)) {
                Pidgey.mandarPeticionComida();
            }
            if ("Pidgeotto".equals(pokemon)) {
                Pidgeotto.mandarPeticionComida();
            }
            if ("Pidgeot".equals(pokemon)) {
                Pidgeot.mandarPeticionComida();
            }
            if ("Rattata".equals(pokemon)) {
                Rattata.mandarPeticionComida();
            }
            if ("Raticate".equals(pokemon)) {
                Raticate.mandarPeticionComida();
            }
            if ("Spearow".equals(pokemon)) {
                Spearow.mandarPeticionComida();
            }
            if ("Fearow".equals(pokemon)) {
                Fearow.mandarPeticionComida();
            }
            if ("Ekans".equals(pokemon)) {
                Ekans.mandarPeticionComida();
            }
            if ("Arbok".equals(pokemon)) {
                Arbok.mandarPeticionComida();
            }
            if ("Pikachu".equals(pokemon)) {
                Pikachu.mandarPeticionComida();
            }
            if ("Raichu".equals(pokemon)) {
                Raichu.mandarPeticionComida();
            }
            if ("Sandshrew".equals(pokemon)) {
                Sandshrew.mandarPeticionComida();
            }
            if ("Sandslash".equals(pokemon)) {
                Sandslash.mandarPeticionComida();
            }
            if ("Nidoran".equals(pokemon)) {
                Nidoran.mandarPeticionComida();
            }
            if ("Nidorina".equals(pokemon)) {
                Nidorina.mandarPeticionComida();
            }
            if ("Nidoqueen".equals(pokemon)) {
                Nidoqueen.mandarPeticionComida();
            }
            if ("Nidorann".equals(pokemon)) {
                Nidorann.mandarPeticionComida();
            }
            if ("Nidorino".equals(pokemon)) {
                Nidorino.mandarPeticionComida();
            }
            if ("Nidoking".equals(pokemon)) {
                Nidoking.mandarPeticionComida();
            }
            if ("Clefairy".equals(pokemon)) {
                Clefairy.mandarPeticionComida();
            }
            if ("Clefable".equals(pokemon)) {
                Clefable.mandarPeticionComida();
            }
            if ("Vulpix".equals(pokemon)) {
                Vulpix.mandarPeticionComida();
            }
            if ("Ninetales".equals(pokemon)) {
                Ninetales.mandarPeticionComida();
            }
            if ("Jigglypuff".equals(pokemon)) {
                Jigglypuff.mandarPeticionComida();
            }
            if ("Wigglytuff".equals(pokemon)) {
                Wigglytuff.mandarPeticionComida();
            }
            if ("Zubat".equals(pokemon)) {
                Zubat.mandarPeticionComida();
            }
            if ("Golbat".equals(pokemon)) {
                Golbat.mandarPeticionComida();
            }
            if ("Oddish".equals(pokemon)) {
                Oddish.mandarPeticionComida();
            }
            if ("Gloom".equals(pokemon)) {
                Gloom.mandarPeticionComida();
            }
            if ("Vileplume".equals(pokemon)) {
                Vileplume.mandarPeticionComida();
            }
            if ("Paras".equals(pokemon)) {
                Paras.mandarPeticionComida();
            }
            if ("Paracect".equals(pokemon)) {
                Parasect.mandarPeticionComida();
            }
            if ("Venonat".equals(pokemon)) {
                Venonat.mandarPeticionComida();
            }
            if ("Venomoth".equals(pokemon)) {
                Venomoth.mandarPeticionComida();
            }
            if ("Diglett".equals(pokemon)) {
                Diglett.mandarPeticionComida();
            }
            if ("Dugtrio".equals(pokemon)) {
                Dugtrio.mandarPeticionComida();
            }
            if ("Meowth".equals(pokemon)) {
                Meowth.mandarPeticionComida();
            }
            if ("Persian".equals(pokemon)) {
                Persian.mandarPeticionComida();
            }
            if ("Psyduck".equals(pokemon)) {
                Psyduck.mandarPeticionComida();
            }
            if ("Golduck".equals(pokemon)) {
                Golduck.mandarPeticionComida();
            }
            if ("Mankey".equals(pokemon)) {
                Mankey.mandarPeticionComida();
            }
            if ("Primeape".equals(pokemon)) {
                Primeape.mandarPeticionComida();
            }
            if ("Growlithe".equals(pokemon)) {
                Growlithe.mandarPeticionComida();
            }
            if ("Arcanine".equals(pokemon)) {
                Arcanine.mandarPeticionComida();
            }
            if ("Poliwag".equals(pokemon)) {
                Poliwag.mandarPeticionComida();
            }
            if ("Poliwhirl".equals(pokemon)) {
                Poliwhirl.mandarPeticionComida();
            }
            if ("Poliwrath".equals(pokemon)) {
                Poliwrath.mandarPeticionComida();
            }
            if ("Abra".equals(pokemon)) {
                Abra.mandarPeticionComida();
            }
            if ("Kadabra".equals(pokemon)) {
                Kadabra.mandarPeticionComida();
            }
            if ("Alakazam".equals(pokemon)) {
                Alakazam.mandarPeticionComida();
            }
            if ("Machop".equals(pokemon)) {
                Machop.mandarPeticionComida();
            }
            if ("Machoke".equals(pokemon)) {
                Machoke.mandarPeticionComida();
            }
            if ("Machamp".equals(pokemon)) {
                Machamp.mandarPeticionComida();
            }
            if ("Bellsprout".equals(pokemon)) {
                Bellsprout.mandarPeticionComida();
            }
            if ("Weepinbell".equals(pokemon)) {
                Weepinbell.mandarPeticionComida();
            }
            if ("Victreebel".equals(pokemon)) {
                Victreebel.mandarPeticionComida();
            }
            if ("Tentacool".equals(pokemon)) {
                Tentacool.mandarPeticionComida();
            }
            if ("Tentacruel".equals(pokemon)) {
                Tentacruel.mandarPeticionComida();
            }
            if ("Geodude".equals(pokemon)) {
                Geodude.mandarPeticionComida();
            }
            if ("Graveler".equals(pokemon)) {
                Graveler.mandarPeticionComida();
            }
            if ("Golem".equals(pokemon)) {
                Golem.mandarPeticionComida();
            }
            if ("Ponyta".equals(pokemon)) {
                Ponyta.mandarPeticionComida();
            }
            if ("Rapidash".equals(pokemon)) {
                Rapidash.mandarPeticionComida();
            }
            if ("Slowpoke".equals(pokemon)) {
                Slowpoke.mandarPeticionComida();
            }
            if ("Slowbro".equals(pokemon)) {
                Slowbro.mandarPeticionComida();
            }
            if ("Magnemite".equals(pokemon)) {
                Magnemite.mandarPeticionComida();
            }
            if ("Magneton".equals(pokemon)) {
                Magneton.mandarPeticionComida();
            }
            if ("Farfetchd".equals(pokemon)) {
                Farfetchd.mandarPeticionComida();
            }
            if ("Doduo".equals(pokemon)) {
                Doduo.mandarPeticionComida();
            }
            if ("Dodrio".equals(pokemon)) {
                Dodrio.mandarPeticionComida();
            }
            if ("Seel".equals(pokemon)) {
                Seel.mandarPeticionComida();
            }
            if ("Dewgong".equals(pokemon)) {
                Dewgong.mandarPeticionComida();
            }
            if ("Grimer".equals(pokemon)) {
                Grimer.mandarPeticionComida();
            }
            if ("Muk".equals(pokemon)) {
                Muk.mandarPeticionComida();
            }
            if ("Shellder".equals(pokemon)) {
                Shellder.mandarPeticionComida();
            }
            if ("Cloyster".equals(pokemon)) {
                Cloyster.mandarPeticionComida();
            }
            if ("Gastly".equals(pokemon)) {
                Gastly.mandarPeticionComida();
            }
            if ("Haunter".equals(pokemon)) {
                Haunter.mandarPeticionComida();
            }
            if ("Gengar".equals(pokemon)) {
                Gengar.mandarPeticionComida();
            }
            if ("Onix".equals(pokemon)) {
                Onix.mandarPeticionComida();
            }
            if ("Drowzee".equals(pokemon)) {
                Drowzee.mandarPeticionComida();
            }
            if ("Hypno".equals(pokemon)) {
                Hypno.mandarPeticionComida();
            }
            if ("Krabby".equals(pokemon)) {
                Krabby.mandarPeticionComida();
            }
            if ("Kingler".equals(pokemon)) {
                Kingler.mandarPeticionComida();
            }
            if ("Voltorb".equals(pokemon)) {
                Voltorb.mandarPeticionComida();
            }
            if ("Electrode".equals(pokemon)) {
                Electrode.mandarPeticionComida();
            }
            if ("Exeggcute".equals(pokemon)) {
                Exeggcute.mandarPeticionComida();
            }
            if ("Exeggutor".equals(pokemon)) {
                Exeggutor.mandarPeticionComida();
            }
            if ("Cubone".equals(pokemon)) {
                Cubone.mandarPeticionComida();
            }
            if ("Marowark".equals(pokemon)) {
                Marowak.mandarPeticionComida();
            }
            if ("Hitmonlee".equals(pokemon)) {
                Hitmonlee.mandarPeticionComida();
            }
            if ("Hitmonchan".equals(pokemon)) {
                Hitmonchan.mandarPeticionComida();
            }
            if ("Lickitung".equals(pokemon)) {
                Lickitung.mandarPeticionComida();
            }
            if ("Koffing".equals(pokemon)) {
                Koffing.mandarPeticionComida();
            }
            if ("Weezing".equals(pokemon)) {
                Weezing.mandarPeticionComida();
            }
            if ("Rhyhorn".equals(pokemon)) {
                Rhyhorn.mandarPeticionComida();
            }
            if ("Rhydon".equals(pokemon)) {
                Rhydon.mandarPeticionComida();
            }
            if ("Chansey".equals(pokemon)) {
                Chansey.mandarPeticionComida();
            }
            if ("Tangela".equals(pokemon)) {
                Tangela.mandarPeticionComida();
            }
            if ("Kangaskhan".equals(pokemon)) {
                Kangaskhan.mandarPeticionComida();
            }
            if ("Horsea".equals(pokemon)) {
                Horsea.mandarPeticionComida();
            }
            if ("Seadra".equals(pokemon)) {
                Seadra.mandarPeticionComida();
            }
            if ("Goldeen".equals(pokemon)) {
                Goldeen.mandarPeticionComida();
            }
            if ("Seaking".equals(pokemon)) {
                Seaking.mandarPeticionComida();
            }
            if ("Staryu".equals(pokemon)) {
                Staryu.mandarPeticionComida();
            }
            if ("Starmie".equals(pokemon)) {
                Starmie.mandarPeticionComida();
            }
            if ("MrMime".equals(pokemon)) {
                MrMime.mandarPeticionComida();
            }
            if ("Scyther".equals(pokemon)) {
                Scyther.mandarPeticionComida();
            }
            if ("Jynx".equals(pokemon)) {
                Jynx.mandarPeticionComida();
            }
            if ("Electabuzz".equals(pokemon)) {
                Electabuzz.mandarPeticionComida();
            }
            if ("Magmar".equals(pokemon)) {
                Magmar.mandarPeticionComida();
            }
            if ("Pinsir".equals(pokemon)) {
                Pinsir.mandarPeticionComida();
            }
            if ("Tauros".equals(pokemon)) {
                Tauros.mandarPeticionComida();
            }
            if ("Magikarp".equals(pokemon)) {
                Magikarp.mandarPeticionComida();
            }
            if ("Gyarados".equals(pokemon)) {
                Gyarados.mandarPeticionComida();
            }
            if ("Lapras".equals(pokemon)) {
                Lapras.mandarPeticionComida();
            }
            if ("Ditto".equals(pokemon)) {
                Ditto.mandarPeticionComida();
            }
            if ("Eevee".equals(pokemon)) {
                Eevee.mandarPeticionComida();
            }
            if ("Vaporeon".equals(pokemon)) {
                Vaporeon.mandarPeticionComida();
            }
            if ("Jolteon".equals(pokemon)) {
                Jolteon.mandarPeticionComida();
            }
            if ("Flareon".equals(pokemon)) {
                Flareon.mandarPeticionComida();
            }
            if ("Porygon".equals(pokemon)) {
                Porygon.mandarPeticionComida();
            }
            if ("Omanyte".equals(pokemon)) {
                Omanyte.mandarPeticionComida();
            }
            if ("Omastar".equals(pokemon)) {
                Omastar.mandarPeticionComida();
            }
            if ("Kabuto".equals(pokemon)) {
                Kabuto.mandarPeticionComida();
            }
            if ("Kabutops".equals(pokemon)) {
                Kabutops.mandarPeticionComida();
            }
            if ("Aerodactyl".equals(pokemon)) {
                Aerodactyl.mandarPeticionComida();
            }
            if ("Snorlax".equals(pokemon)) {
                Snorlax.mandarPeticionComida();
            }
            if ("Articuno".equals(pokemon)) {
                Articuno.mandarPeticionComida();
            }
            if ("Zapdos".equals(pokemon)) {
                Zapdos.mandarPeticionComida();
            }
            if ("Moltres".equals(pokemon)) {
                Moltres.mandarPeticionComida();
            }
        if ("Dratini".equals(pokemon)) {
            Dratini.mandarPeticionComida();
        }
        if ("Dragonair".equals(pokemon)) {
            Dragonair.mandarPeticionComida();
        }
        if ("Dragonite".equals(pokemon)) {
            Dragonite.mandarPeticionComida();
        }
        if ("Mewtwo".equals(pokemon)) {
            Mewtwo.mandarPeticionComida();
        }
        if ("Mew".equals(pokemon)) {
            Mew.mandarPeticionComida();
        }  
    }//GEN-LAST:event_SiActionPerformed

    private void NoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NoActionPerformed
        this.dispose();
    }//GEN-LAST:event_NoActionPerformed

    private void Si2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Si2ActionPerformed
        No2.setEnabled(false);
        ConsultarApodo.setText("Escriba el apodo que desea ponerle a su nuevo pokemon:");
        NuevoNombre.setVisible(true);
        Aceptar.setVisible(true);
    }//GEN-LAST:event_Si2ActionPerformed

    private void No2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_No2ActionPerformed
        adquirirPokemon();
        this.dispose();
    }//GEN-LAST:event_No2ActionPerformed

    private void AceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AceptarActionPerformed
        pokemon = obtenerApodo();
        adquirirPokemon();
        this.dispose();
    }//GEN-LAST:event_AceptarActionPerformed
    
    private String obtenerApodo() {
        return String.valueOf(NuevoNombre.getText());
    }
    
    protected void adquirirPokemon() {
        for (int contador = 0; contador < 10; contador++) {
            if("------".equals(pokemonJugador[contador])) {
		pokemonJugador[contador] = pokemon;
		dinero = dinero - 50; 
                break;
            }
	}
    }
    
    protected void adquirirRepuesto() {
        for (int contador = 0; contador < 10; contador++) {
            if("------".equals(pokemonRepuesto[contador])) {
		pokemonRepuesto[contador] = pokemon;
                break;
            }
	}
    }
        
    protected int devolverDinero() {
        return dinero;
    }
    /**
     * @param args the command line arguments
     */


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Aceptar;
    private javax.swing.JLabel ConsultarApodo;
    private javax.swing.JLabel Contexto;
    private javax.swing.JLabel Contexto1;
    private javax.swing.JLabel Escritura;
    private javax.swing.JButton No;
    private javax.swing.JButton No2;
    private javax.swing.JTextField NuevoNombre;
    private javax.swing.JLabel Pregunta;
    private javax.swing.JButton Si;
    private javax.swing.JButton Si2;
    private javax.swing.JLabel Titulo;
    private javax.swing.JButton comprar;
    private javax.swing.JTextField numeroDeCompra;
    // End of variables declaration//GEN-END:variables
}
