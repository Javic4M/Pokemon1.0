/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.pokemonsjuego.juegoCompleto.frameYPngs;

import com.mycompany.pokemonsjuego.juegoCompleto.pokemon.*;
import javax.swing.JOptionPane;

/**
 *
 * @author DELL
 */
public class ComprarMedicina extends javax.swing.JFrame {

    private String pokemonJugador[];
    private String pokemonRepuesto[];
    private Bulbasaur Bulbasaur;
    private Ivysaur Ivysaur;
    private Venusaur Venusaur;
    private Charmander Charmander;
    private Charmeleon Charmeleon;
    private Charizard Charizard;
    private Squirtle Squirtle;
    private Wartortle Wartortle;
    private Blastoise Blastoise;
    private Caterpie Caterpie;
    private Metapod Metapod;
    private Butterfree Butterfree;
    private Weedle Weedle;
    private Kakuna Kakuna;
    private Beedrill Beedrill;
    private Pidgey Pidgey;
    private Pidgeotto Pidgeotto;
    private Pidgeot Pidgeot;
    private Rattata Rattata;
    private Raticate Raticate;
    private Spearow Spearow;
    private Fearow Fearow;
    private Ekans Ekans;
    private Arbok Arbok;
    private Pikachu Pikachu;
    private Raichu Raichu;
    private Sandshrew Sandshrew;
    private Sandslash Sandslash;
    private Nidoran Nidoran;
    private Nidorina Nidorina;
    private Nidoqueen Nidoqueen;
    private Nidorann Nidorann;
    private Nidorino Nidorino;
    private Nidoking Nidoking;
    private Clefairy Clefairy;
    private Clefable Clefable;
    private Vulpix Vulpix;
    private Ninetales Ninetales;
    private Jigglypuff Jigglypuff;
    private Wigglytuff Wigglytuff;
    private Zubat Zubat;
    private Golbat Golbat;
    private Oddish Oddish;
    private Gloom Gloom;
    private Vileplume Vileplume;
    private Paras Paras;
    private Parasect Parasect;
    private Venonat Venonat;
    private Venomoth Venomoth;
    private Diglett Diglett;
    private Dugtrio Dugtrio;
    private Meowth Meowth;
    private Persian Persian;
    private Psyduck Psyduck;
    private Golduck Golduck;
    private Mankey Mankey;
    private Primeape Primeape;
    private Growlithe Growlithe;
    private Arcanine Arcanine;
    private Poliwag Poliwag;
    private Poliwhirl Poliwhirl;
    private Poliwrath Poliwrath;
    private Abra Abra;
    private Kadabra Kadabra;
    private Alakazam Alakazam;
    private Machop Machop;
    private Machoke Machoke;
    private Machamp Machamp;
    private Bellsprout Bellsprout;
    private Weepinbell Weepinbell;
    private Victreebel Victreebel;
    private Tentacool Tentacool;
    private Tentacruel Tentacruel;
    private Geodude Geodude;
    private Graveler Graveler;
    private Golem Golem;
    private Ponyta Ponyta;
    private Rapidash Rapidash;
    private Slowpoke Slowpoke;
    private Slowbro Slowbro;
    private Magnemite Magnemite;
    private Magneton Magneton;
    private Farfetchd Farfetchd;
    private Doduo Doduo;
    private Dodrio Dodrio;
    private Seel Seel;
    private Dewgong Dewgong;
    private Grimer Grimer;
    private Muk Muk;
    private Shellder Shellder;
    private Cloyster Cloyster;
    private Gastly Gastly;
    private Haunter Haunter;
    private Gengar Gengar;
    private Onix Onix;
    private Drowzee Drowzee;
    private Hypno Hypno;
    private Krabby Krabby;
    private Kingler Kingler;
    private Voltorb Voltorb;
    private Electrode Electrode;
    private Exeggcute Exeggcute;
    private Exeggutor Exeggutor;
    private Cubone Cubone;
    private Marowak Marowak;
    private Hitmonlee Hitmonlee;
    private Hitmonchan Hitmonchan;
    private Lickitung Lickitung;
    private Koffing Koffing;
    private Weezing Weezing;
    private Rhyhorn Rhyhorn;
    private Rhydon Rhydon;
    private Chansey Chansey;
    private Tangela Tangela;
    private Kangaskhan Kangaskhan;
    private Horsea Horsea;
    private Seadra Seadra;
    private Goldeen Goldeen;
    private Seaking Seaking;
    private Staryu Staryu;
    private Starmie Starmie;
    private MrMime MrMime;
    private Scyther Scyther;
    private Jynx Jynx;
    private Electabuzz Electabuzz;
    private Magmar Magmar;
    private Pinsir Pinsir;
    private Tauros Tauros;
    private Magikarp Magikarp;
    private Gyarados Gyarados;
    private Lapras Lapras;
    private Ditto Ditto;
    private Eevee Eevee;
    private Vaporeon Vaporeon;
    private Jolteon Jolteon;
    private Flareon Flareon;
    private Porygon Porygon;
    private Omanyte Omanyte;
    private Omastar Omastar;
    private Kabuto Kabuto;
    private Kabutops Kabutops;
    private Aerodactyl Aerodactyl;
    private Snorlax Snorlax;
    private Articuno Articuno;
    private Zapdos Zapdos;
    private Moltres Moltres;
    private Dratini Dratini;
    private Dragonair Dragonair;
    private Dragonite Dragonite;
    private Mewtwo Mewtwo;
    private Mew Mew;
    private int dinero;
    private String medicina = null;
    private String pokemon = null;
    
    /**
     * Creates new form ComprarMedicina
     */
    public ComprarMedicina(int dinero, String pokemonJugador[], String pokemonRepuesto[]) {
        initComponents();
        this.dinero = dinero;
        this.pokemonJugador = pokemonJugador;
        this.pokemonRepuesto = pokemonRepuesto;
        Bulbasaur = new Bulbasaur();
        Ivysaur = new Ivysaur();
        Venusaur = new Venusaur();
        Charmander = new Charmander();
        Charmeleon = new Charmeleon();
        Charizard = new Charizard();
        Squirtle = new Squirtle();
        Wartortle = new Wartortle();
        Blastoise = new Blastoise();
        Caterpie = new Caterpie();
        Metapod = new Metapod();
        Butterfree = new Butterfree();
        Weedle = new Weedle();
        Kakuna = new Kakuna();
        Beedrill = new Beedrill();
        Pidgey = new Pidgey();
        Pidgeotto = new Pidgeotto();
        Pidgeot = new Pidgeot();
        Rattata = new Rattata();
        Raticate = new Raticate();
        Spearow = new Spearow();
        Fearow = new Fearow();
        Ekans = new Ekans();
        Arbok = new Arbok();
        Pikachu = new Pikachu();
        Raichu = new Raichu();
        Sandshrew = new Sandshrew();
        Sandslash = new Sandslash();
        Nidoran = new Nidoran();
        Nidoqueen = new Nidoqueen();
        Nidorann = new Nidorann();
        Nidorino = new Nidorino();
        Nidoking = new Nidoking();
        Clefairy = new Clefairy();
        Clefable = new Clefable();
        Vulpix = new Vulpix();
        Ninetales = new Ninetales();
        Jigglypuff = new Jigglypuff();
        Wigglytuff = new Wigglytuff();
        Zubat = new Zubat();
        Golbat = new Golbat();
        Oddish = new Oddish();
        Gloom = new Gloom();
        Vileplume = new Vileplume();
        Paras = new Paras();
        Parasect = new Parasect();
        Venonat = new Venonat();
        Venomoth = new Venomoth();
        Diglett = new Diglett();
        Dugtrio = new Dugtrio();
        Meowth = new Meowth();
        Persian = new Persian();
        Psyduck = new Psyduck();
        Golduck = new Golduck();
        Mankey = new Mankey();
        Primeape = new Primeape();
        Growlithe = new Growlithe();
        Arcanine = new Arcanine();
        Poliwag = new Poliwag();
        Poliwhirl = new Poliwhirl();
        Poliwrath = new Poliwrath();
        Abra = new Abra();
        Kadabra = new Kadabra();
        Alakazam = new Alakazam();
        Machop = new Machop();
        Machoke = new Machoke();
        Machamp = new Machamp();
        Bellsprout = new Bellsprout();
        Weepinbell = new Weepinbell();
        Victreebel = new Victreebel();
        Tentacool = new Tentacool();
        Tentacruel = new Tentacruel();
        Geodude = new Geodude();
        Graveler = new Graveler();
        Golem = new Golem();
        Ponyta = new Ponyta();
        Rapidash = new Rapidash();
        Slowpoke = new Slowpoke();
        Slowbro = new Slowbro();
        Magnemite = new Magnemite();
        Magneton = new Magneton();
        Farfetchd = new Farfetchd();
        Doduo = new Doduo();
        Dodrio = new Dodrio();
        Seel = new Seel();
        Dewgong = new Dewgong();
        Grimer = new Grimer();
        Muk = new Muk();
        Shellder = new Shellder();
        Cloyster = new Cloyster();
        Gastly = new Gastly();
        Haunter = new Haunter();
        Gengar = new Gengar();
        Onix = new Onix();
        Drowzee = new Drowzee();
        Hypno = new Hypno();
        Krabby = new Krabby();
        Kingler = new Kingler();
        Voltorb = new Voltorb();        
        Electrode = new Electrode();
        Exeggcute = new Exeggcute();
        Exeggutor = new Exeggutor();
        Cubone = new Cubone();
        Marowak = new Marowak();
        Hitmonlee = new Hitmonlee();
        Hitmonchan = new Hitmonchan();
        Lickitung = new Lickitung();
        Koffing = new Koffing();
        Weezing = new Weezing();
        Rhyhorn = new Rhyhorn();
        Rhydon = new Rhydon();
        Chansey = new Chansey();
        Tangela = new Tangela();
        Kangaskhan = new Kangaskhan();
        Horsea = new Horsea();
        Seadra = new Seadra();
        Goldeen = new Goldeen();
        Seaking = new Seaking();
        Staryu = new Staryu();
        Starmie = new Starmie();
        MrMime = new MrMime();
        Scyther = new Scyther();
        Jynx = new Jynx();
        Electabuzz = new Electabuzz();
        Magmar = new Magmar();     
        Pinsir = new Pinsir();
        Tauros = new Tauros();
        Magikarp = new Magikarp();
        Gyarados = new Gyarados();
        Lapras = new Lapras();
        Ditto = new Ditto();
        Eevee = new Eevee();
        Vaporeon = new Vaporeon();
        Jolteon = new Jolteon();
        Flareon = new Flareon();
        Porygon = new Porygon();
        Omanyte = new Omanyte();
        Omastar = new Omastar();
        Kabuto = new Kabuto();
        Kabutops = new Kabutops();
        Aerodactyl = new Aerodactyl();   
        Snorlax = new Snorlax();
        Articuno = new Articuno();
        Zapdos = new Zapdos();
        Moltres = new Moltres();
        Dratini = new Dratini();
        Dragonair = new Dragonair();
        Dragonite = new Dragonite();
        Mewtwo = new Mewtwo();
        Mew = new Mew();
        NumeroPokemon.setVisible(false);
        DarMedicina.setVisible(false);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        NumeroDeCompra = new javax.swing.JTextField();
        Comprar = new javax.swing.JButton();
        NumeroPokemon = new javax.swing.JTextField();
        DarMedicina = new javax.swing.JButton();
        PreguntarCualPokemon = new javax.swing.JLabel();

        jLabel1.setFont(new java.awt.Font("Rockwell", 3, 18)); // NOI18N
        jLabel1.setText("Farmacia");

        jLabel2.setText("Escriba el número del medicamento que desea comprar");

        jLabel3.setText("1) Vitamina con un precio de 20 monedas");

        jLabel4.setText("2) Analgesico con un precio de 50 monedas");

        jLabel5.setText("3) Antibiotico con un precio de 80 monedas");

        Comprar.setText("Comprar");
        Comprar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComprarActionPerformed(evt);
            }
        });

        DarMedicina.setText("Dar Medicina");
        DarMedicina.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DarMedicinaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(67, 67, 67)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel3)
                            .addComponent(jLabel5)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(45, 45, 45)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(NumeroPokemon, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(NumeroDeCompra, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 116, Short.MAX_VALUE))
                            .addComponent(Comprar)
                            .addComponent(DarMedicina)
                            .addComponent(PreguntarCualPokemon, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(137, 137, 137)
                        .addComponent(jLabel1)))
                .addContainerGap(51, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5)
                .addGap(18, 18, 18)
                .addComponent(NumeroDeCompra, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Comprar)
                .addGap(20, 20, 20)
                .addComponent(PreguntarCualPokemon, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(NumeroPokemon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(DarMedicina)
                .addContainerGap(39, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ComprarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComprarActionPerformed
        if (dinero >= 10) {             
            if (dinero >= 80) {
                if (obtenerNumeroCompra() > 0 && obtenerNumeroCompra() < 4) {
                    if (obtenerNumeroCompra() == 1) {
                        medicina = "Vitamina";
                        dinero = dinero - 20;
                    } 
                    if (obtenerNumeroCompra() == 2) {
                        medicina = "Analgesico";
                        dinero = dinero - 50;
                    } 
                    if (obtenerNumeroCompra() == 3) {
                        medicina = "Antibiotico";
                        dinero = dinero - 80;
                    } 
                    PreguntarCualPokemon.setText("Escriba el número del Pokemon que desea alimentar:");
                    NumeroDeCompra.setEnabled(false);
                    Comprar.setEnabled(false);
                    NumeroPokemon.setVisible(true);
                    DarMedicina.setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(this,"Número Incorrecto","Error",JOptionPane.ERROR_MESSAGE);
                }                 
            }
            if (dinero >= 50 && dinero < 80) {
                if (obtenerNumeroCompra() > 0 && obtenerNumeroCompra() < 4) {
                    if (obtenerNumeroCompra() == 1) {
                        medicina = "Vitamina";
                        dinero = dinero - 20;
                        PreguntarCualPokemon.setText("Escriba el número del Pokemon que desea alimentar:");
                        NumeroDeCompra.setEnabled(false);
                        Comprar.setEnabled(false);
                        NumeroPokemon.setVisible(true);
                        DarMedicina.setVisible(true);
                    } 
                    if (obtenerNumeroCompra() == 2) {
                        medicina = "Analgesico";
                        dinero = dinero - 50;
                        PreguntarCualPokemon.setText("Escriba el número del Pokemon que desea alimentar:");
                        NumeroDeCompra.setEnabled(false);
                        Comprar.setEnabled(false);
                        NumeroPokemon.setVisible(true);
                        DarMedicina.setVisible(true);
                    } 
                    if (obtenerNumeroCompra() == 3) {
                        JOptionPane.showMessageDialog(this,"No tienes suficiente dinero para comprar Antibiotico","Falta de Dinero",JOptionPane.INFORMATION_MESSAGE);
                    } 
                } else {
                    JOptionPane.showMessageDialog(this,"Número Incorrecto","Error",JOptionPane.ERROR_MESSAGE);
                }                 
            }
            if (dinero >= 20 && dinero < 50) {
                if (obtenerNumeroCompra() > 0 && obtenerNumeroCompra() < 4) {
                    if (obtenerNumeroCompra() == 1) {
                        medicina = "Vitamina";
                        dinero = dinero - 20;
                        PreguntarCualPokemon.setText("Escriba el número del Pokemon que desea alimentar:");
                        NumeroDeCompra.setEnabled(false);
                        Comprar.setEnabled(false);
                        NumeroPokemon.setVisible(true);
                        DarMedicina.setVisible(true);
                    } 
                    if (obtenerNumeroCompra() == 2) {
                        JOptionPane.showMessageDialog(this,"No tienes suficiente dinero para comprar Analgesico","Falta de Dinero",JOptionPane.INFORMATION_MESSAGE);
                    } 
                    if (obtenerNumeroCompra() == 3) {
                        JOptionPane.showMessageDialog(this,"No tienes suficiente dinero para comprar Antibiotico","Falta de Dinero",JOptionPane.INFORMATION_MESSAGE);
                    } 
                } else {
                    JOptionPane.showMessageDialog(this,"Número Incorrecto","Error",JOptionPane.ERROR_MESSAGE);
                }                  
            }         
        } else {
            JOptionPane.showMessageDialog(this,"No tienes suficiente dinero para Comprar","Error",JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_ComprarActionPerformed

    private void DarMedicinaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DarMedicinaActionPerformed
        if (obtenerNumeroPokemon() > 0 && obtenerNumeroPokemon() < 11) {
            if (obtenerNumeroPokemon() == 1) {
                pokemon = pokemonRepuesto[0];
                enviarMedicina();
                JOptionPane.showMessageDialog(this,pokemonJugador[0] + " fue Curado","Medicina",JOptionPane.INFORMATION_MESSAGE);
            }
            if (obtenerNumeroPokemon() == 2) {
                pokemon = pokemonRepuesto[1];
                enviarMedicina();
                JOptionPane.showMessageDialog(this,pokemonJugador[1] + " fue Curado","Medicina",JOptionPane.INFORMATION_MESSAGE);
            }
            if (obtenerNumeroPokemon() == 3) {
                pokemon = pokemonRepuesto[2];
                enviarMedicina();
                JOptionPane.showMessageDialog(this,pokemonJugador[2] + " fue Curado","Medicina",JOptionPane.INFORMATION_MESSAGE);
            }
            if (obtenerNumeroPokemon() == 4) {
                pokemon = pokemonRepuesto[3];
                enviarMedicina();
                JOptionPane.showMessageDialog(this,pokemonJugador[3] + " fue Curado","Medicina",JOptionPane.INFORMATION_MESSAGE);
            }
            if (obtenerNumeroPokemon() == 5) {
                pokemon = pokemonRepuesto[4];
                enviarMedicina();
                JOptionPane.showMessageDialog(this,pokemonJugador[4] + " fue Curado","Medicina",JOptionPane.INFORMATION_MESSAGE);
            }
            if (obtenerNumeroPokemon() == 6) {
                pokemon = pokemonRepuesto[5];
                enviarMedicina();
                JOptionPane.showMessageDialog(this,pokemonJugador[5] + " fue Curado","Medicina",JOptionPane.INFORMATION_MESSAGE);
            }
            if (obtenerNumeroPokemon() == 7) {
                pokemon = pokemonRepuesto[6];
                enviarMedicina();
                JOptionPane.showMessageDialog(this,pokemonJugador[6] + " fue Curado","Medicina",JOptionPane.INFORMATION_MESSAGE);
            }
            if (obtenerNumeroPokemon() == 8) {
                pokemon = pokemonRepuesto[7];
                enviarMedicina();
                JOptionPane.showMessageDialog(this,pokemonJugador[7] + " fue Curado","Medicina",JOptionPane.INFORMATION_MESSAGE);
            }
            if (obtenerNumeroPokemon() == 9) {
                pokemon = pokemonRepuesto[8];
                enviarMedicina();
                JOptionPane.showMessageDialog(this,pokemonJugador[8] + " fue Curado","Medicina",JOptionPane.INFORMATION_MESSAGE);
            }
            if (obtenerNumeroPokemon() == 10) {
                pokemon = pokemonRepuesto[9];
                enviarMedicina();
                JOptionPane.showMessageDialog(this,pokemonJugador[9] + " fue Curado","Comida",JOptionPane.INFORMATION_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this,"Número Incorrecto","Error",JOptionPane.ERROR_MESSAGE);
        }
        this.dispose();
    }//GEN-LAST:event_DarMedicinaActionPerformed

    private void enviarMedicina() {
        if ("Bulbasaur".equals(pokemon)) {
            Bulbasaur.recibirMedicina(medicina);
        }
        if ("Ivysaur".equals(pokemon)) {
            Ivysaur.recibirMedicina(medicina);
        }
        if ("Venusaur".equals(pokemon)) {
            Venusaur.recibirMedicina(medicina);
        }
        if ("Charmander".equals(pokemon)) {
            Charmander.recibirMedicina(medicina);
        }
        if ("Charmeleon".equals(pokemon)) {
            Charmeleon.recibirMedicina(medicina);
        }
        if ("Charizard".equals(pokemon)) {
            Charizard.recibirMedicina(medicina);
        }
        if ("Squirtle".equals(pokemon)) {
            Squirtle.recibirMedicina(medicina);
        }
        if ("Wartortle".equals(pokemon)) {
            Wartortle.recibirMedicina(medicina);
        }
        if ("Blastoise".equals(pokemon)) {
            Blastoise.recibirMedicina(medicina);
        }
        if ("Caterpie".equals(pokemon)) {
            Caterpie.recibirMedicina(medicina);
        }
        if ("Metapod".equals(pokemon)) {
            Metapod.recibirMedicina(medicina);
        }
        if ("Butterfreee".equals(pokemon)) {
            Butterfree.recibirMedicina(medicina);
        }
        if ("Weedle".equals(pokemon)) {
            Weedle.recibirMedicina(medicina);
        }
        if ("Kakuna".equals(pokemon)) {
            Kakuna.recibirMedicina(medicina);
        }
        if ("Beedrill".equals(pokemon)) {
            Beedrill.recibirMedicina(medicina);
        }
        if ("Pidgey".equals(pokemon)) {
            Pidgey.recibirMedicina(medicina);
        }
        if ("Pidgeotto".equals(pokemon)) {
            Pidgeotto.recibirMedicina(medicina);
        }
        if ("Pidgeot".equals(pokemon)) {
            Pidgeot.recibirMedicina(medicina);
        }
        if ("Rattata".equals(pokemon)) {
            Rattata.recibirMedicina(medicina);
        }
        if ("Raticate".equals(pokemon)) {
            Raticate.recibirMedicina(medicina);
        }
        if ("Spearow".equals(pokemon)) {
            Spearow.recibirMedicina(medicina);
        }
        if ("Fearow".equals(pokemon)) {
            Fearow.recibirMedicina(medicina);
        }
        if ("Ekans".equals(pokemon)) {
            Ekans.recibirMedicina(medicina);
        }
        if ("Arbok".equals(pokemon)) {
            Arbok.recibirMedicina(medicina);
        }
        if ("Pikachu".equals(pokemon)) {
            Pikachu.recibirMedicina(medicina);
        }
        if ("Raichu".equals(pokemon)) {
            Raichu.recibirMedicina(medicina);
        }
        if ("Sandshrew".equals(pokemon)) {
            Sandshrew.recibirMedicina(medicina);
        }
        if ("Sandslash".equals(pokemon)) {
            Sandslash.recibirMedicina(medicina);
        }
        if ("Nidoran".equals(pokemon)) {
            Nidoran.recibirMedicina(medicina);
        }
        if ("Nidorina".equals(pokemon)) {
            Nidorina.recibirMedicina(medicina);
        }
        if ("Nidoqueen".equals(pokemon)) {
            Nidoqueen.recibirMedicina(medicina);
        }
        if ("Nidorann".equals(pokemon)) {
            Nidorann.recibirMedicina(medicina);
        }
        if ("Nidorino".equals(pokemon)) {
            Nidorino.recibirMedicina(medicina);
        }
        if ("Nidoking".equals(pokemon)) {
            Nidoking.recibirMedicina(medicina);
        }
        if ("Clefairy".equals(pokemon)) {
            Clefairy.recibirMedicina(medicina);
        }
        if ("Clefable".equals(pokemon)) {
            Clefable.recibirMedicina(medicina);
        }
        if ("Vulpix".equals(pokemon)) {
            Vulpix.recibirMedicina(medicina);
        }
        if ("Ninetales".equals(pokemon)) {
            Ninetales.recibirMedicina(medicina);
        }
        if ("Jigglypuff".equals(pokemon)) {
            Jigglypuff.recibirMedicina(medicina);
        }
        if ("Wigglytuff".equals(pokemon)) {
            Wigglytuff.recibirMedicina(medicina);
        }
        if ("Zubat".equals(pokemon)) {
            Zubat.recibirMedicina(medicina);
        }
        if ("Golbat".equals(pokemon)) {
            Golbat.recibirMedicina(medicina);
        }
        if ("Oddish".equals(pokemon)) {
            Oddish.recibirMedicina(medicina);
        }
        if ("Gloom".equals(pokemon)) {
            Gloom.recibirMedicina(medicina);
        }
        if ("Vileplume".equals(pokemon)) {
            Vileplume.recibirMedicina(medicina);
        }
        if ("Paras".equals(pokemon)) {
            Paras.recibirMedicina(medicina);
        }
        if ("Paracect".equals(pokemon)) {
            Parasect.recibirMedicina(medicina);
        }
        if ("Venonat".equals(pokemon)) {
            Venonat.recibirMedicina(medicina);
        }
        if ("Venomoth".equals(pokemon)) {
            Venomoth.recibirMedicina(medicina);
        }
        if ("Diglett".equals(pokemon)) {
            Diglett.recibirMedicina(medicina);
        }
        if ("Dugtrio".equals(pokemon)) {
            Dugtrio.recibirMedicina(medicina);
        }
        if ("Meowth".equals(pokemon)) {
            Meowth.recibirMedicina(medicina);
        }
        if ("Persian".equals(pokemon)) {
            Persian.recibirMedicina(medicina);
        }
        if ("Psyduck".equals(pokemon)) {
            Psyduck.recibirMedicina(medicina);
        }
        if ("Golduck".equals(pokemon)) {
            Golduck.recibirMedicina(medicina);
        }
        if ("Mankey".equals(pokemon)) {
            Mankey.recibirMedicina(medicina);
        }
        if ("Primeape".equals(pokemon)) {
            Primeape.recibirMedicina(medicina);
        }
        if ("Growlithe".equals(pokemon)) {
            Growlithe.recibirMedicina(medicina);
        }
        if ("Arcanine".equals(pokemon)) {
            Arcanine.recibirMedicina(medicina);
        }
        if ("Poliwag".equals(pokemon)) {
            Poliwag.recibirMedicina(medicina);
        }
        if ("Poliwhirl".equals(pokemon)) {
            Poliwhirl.recibirMedicina(medicina);
        }
        if ("Poliwrath".equals(pokemon)) {
            Poliwrath.recibirMedicina(medicina);
        }
        if ("Abra".equals(pokemon)) {
            Abra.recibirMedicina(medicina);
        }
        if ("Kadabra".equals(pokemon)) {
            Kadabra.recibirMedicina(medicina);
        }
        if ("Alakazam".equals(pokemon)) {
            Alakazam.recibirMedicina(medicina);
        }
        if ("Machop".equals(pokemon)) {
            Machop.recibirMedicina(medicina);
        }
        if ("Machoke".equals(pokemon)) {
            Machoke.recibirMedicina(medicina);
        }
        if ("Machamp".equals(pokemon)) {
            Machamp.recibirMedicina(medicina);
        }
        if ("Bellsprout".equals(pokemon)) {
            Bellsprout.recibirMedicina(medicina);
        }
        if ("Weepinbell".equals(pokemon)) {
            Weepinbell.recibirMedicina(medicina);
        }
        if ("Victreebel".equals(pokemon)) {
            Victreebel.recibirMedicina(medicina);
        }
        if ("Tentacool".equals(pokemon)) {
            Tentacool.recibirMedicina(medicina);
        }
        if ("Tentacruel".equals(pokemon)) {
            Tentacruel.recibirMedicina(medicina);
        }
        if ("Geodude".equals(pokemon)) {
            Geodude.recibirMedicina(medicina);
        }
        if ("Graveler".equals(pokemon)) {
            Graveler.recibirMedicina(medicina);
        }
        if ("Golem".equals(pokemon)) {
            Golem.recibirMedicina(medicina);
        }
        if ("Ponyta".equals(pokemon)) {
            Ponyta.recibirMedicina(medicina);
        }
        if ("Rapidash".equals(pokemon)) {
            Rapidash.recibirMedicina(medicina);
        }
        if ("Slowpoke".equals(pokemon)) {
            Slowpoke.recibirMedicina(medicina);
        }
        if ("Slowbro".equals(pokemon)) {
            Slowbro.recibirMedicina(medicina);
        }
        if ("Magnemite".equals(pokemon)) {
            Magnemite.recibirMedicina(medicina);
        }
        if ("Magneton".equals(pokemon)) {
            Magneton.recibirMedicina(medicina);
        }
        if ("Farfetchd".equals(pokemon)) {
            Farfetchd.recibirMedicina(medicina);
        }
        if ("Doduo".equals(pokemon)) {
            Doduo.recibirMedicina(medicina);
        }
        if ("Dodrio".equals(pokemon)) {
            Dodrio.recibirMedicina(medicina);
        }
        if ("Seel".equals(pokemon)) {
            Seel.recibirMedicina(medicina);
        }
        if ("Dewgong".equals(pokemon)) {
            Dewgong.recibirMedicina(medicina);
        }
        if ("Grimer".equals(pokemon)) {
            Grimer.recibirMedicina(medicina);
        }
        if ("Muk".equals(pokemon)) {
            Muk.recibirMedicina(medicina);
        }
        if ("Shellder".equals(pokemon)) {
            Shellder.recibirMedicina(medicina);
        }
        if ("Cloyster".equals(pokemon)) {
            Cloyster.recibirMedicina(medicina);
        }
        if ("Gastly".equals(pokemon)) {
            Gastly.recibirMedicina(medicina);
        }
        if ("Haunter".equals(pokemon)) {
            Haunter.recibirMedicina(medicina);
        }
        if ("Gengar".equals(pokemon)) {
            Gengar.recibirMedicina(medicina);
        }
        if ("Onix".equals(pokemon)) {
            Onix.recibirMedicina(medicina);
        }
        if ("Drowzee".equals(pokemon)) {
            Drowzee.recibirMedicina(medicina);
        }
        if ("Hypno".equals(pokemon)) {
            Hypno.recibirMedicina(medicina);
        }
        if ("Krabby".equals(pokemon)) {
            Krabby.recibirMedicina(medicina);
        }
        if ("Kingler".equals(pokemon)) {
            Kingler.recibirMedicina(medicina);
        }
        if ("Voltorb".equals(pokemon)) {
            Voltorb.recibirMedicina(medicina);
        }
        if ("Electrode".equals(pokemon)) {
            Electrode.recibirMedicina(medicina);
        }
        if ("Exeggcute".equals(pokemon)) {
            Exeggcute.recibirMedicina(medicina);
        }
        if ("Exeggutor".equals(pokemon)) {
            Exeggutor.recibirMedicina(medicina);
        }
        if ("Cubone".equals(pokemon)) {
            Cubone.recibirMedicina(medicina);
        }
        if ("Marowark".equals(pokemon)) {
            Marowak.recibirMedicina(medicina);
        }
        if ("Hitmonlee".equals(pokemon)) {
            Hitmonlee.recibirMedicina(medicina);
        }
        if ("Hitmonchan".equals(pokemon)) {
            Hitmonchan.recibirMedicina(medicina);
        }
        if ("Lickitung".equals(pokemon)) {
            Lickitung.recibirMedicina(medicina);
        }
        if ("Koffing".equals(pokemon)) {
            Koffing.recibirMedicina(medicina);
        }
        if ("Weezing".equals(pokemon)) {
            Weezing.recibirMedicina(medicina);
        }
        if ("Rhyhorn".equals(pokemon)) {
            Rhyhorn.recibirMedicina(medicina);
        }
        if ("Rhydon".equals(pokemon)) {
            Rhydon.recibirMedicina(medicina);
        }
        if ("Chansey".equals(pokemon)) {
            Chansey.recibirMedicina(medicina);
        }
        if ("Tangela".equals(pokemon)) {
            Tangela.recibirMedicina(medicina);
        }
        if ("Kangaskhan".equals(pokemon)) {
            Kangaskhan.recibirMedicina(medicina);
        }
        if ("Horsea".equals(pokemon)) {
            Horsea.recibirMedicina(medicina);
        }
        if ("Seadra".equals(pokemon)) {
            Seadra.recibirMedicina(medicina);
        }
        if ("Goldeen".equals(pokemon)) {
            Goldeen.recibirMedicina(medicina);
        }
        if ("Seaking".equals(pokemon)) {
            Seaking.recibirMedicina(medicina);
        }
        if ("Staryu".equals(pokemon)) {
            Staryu.recibirMedicina(medicina);
        }
        if ("Starmie".equals(pokemon)) {
            Starmie.recibirMedicina(medicina);
        }
        if ("MrMime".equals(pokemon)) {
            MrMime.recibirMedicina(medicina);
        }
        if ("Scyther".equals(pokemon)) {
            Scyther.recibirMedicina(medicina);
        }
        if ("Jynx".equals(pokemon)) {
            Jynx.recibirMedicina(medicina);
        }
        if ("Electabuzz".equals(pokemon)) {
            Electabuzz.recibirMedicina(medicina);
        }
        if ("Magmar".equals(pokemon)) {
            Magmar.recibirMedicina(medicina);
        }
        if ("Pinsir".equals(pokemon)) {
            Pinsir.recibirMedicina(medicina);
        }
        if ("Tauros".equals(pokemon)) {
            Tauros.recibirMedicina(medicina);
        }
        if ("Magikarp".equals(pokemon)) {
            Magikarp.recibirMedicina(medicina);
        }
        if ("Gyarados".equals(pokemon)) {
            Gyarados.recibirMedicina(medicina);
        }
        if ("Lapras".equals(pokemon)) {
            Lapras.recibirMedicina(medicina);
        }
        if ("Ditto".equals(pokemon)) {
            Ditto.recibirMedicina(medicina);
        }
        if ("Eevee".equals(pokemon)) {
            Eevee.recibirMedicina(medicina);
        }
        if ("Vaporeon".equals(pokemon)) {
            Vaporeon.recibirMedicina(medicina);
        }
        if ("Jolteon".equals(pokemon)) {
            Jolteon.recibirMedicina(medicina);
        }
        if ("Flareon".equals(pokemon)) {
            Flareon.recibirMedicina(medicina);
        }
        if ("Porygon".equals(pokemon)) {
            Porygon.recibirMedicina(medicina);
        }
        if ("Omanyte".equals(pokemon)) {
            Omanyte.recibirMedicina(medicina);
        }
        if ("Omastar".equals(pokemon)) {
            Omastar.recibirMedicina(medicina);
        }
        if ("Kabuto".equals(pokemon)) {
            Kabuto.recibirMedicina(medicina);
        }
        if ("Kabutops".equals(pokemon)) {
            Kabutops.recibirMedicina(medicina);
        }
        if ("Aerodactyl".equals(pokemon)) {
            Aerodactyl.recibirMedicina(medicina);
        }
        if ("Snorlax".equals(pokemon)) {
            Snorlax.recibirMedicina(medicina);
        }
        if ("Articuno".equals(pokemon)) {
            Articuno.recibirMedicina(medicina);
        }
        if ("Zapdos".equals(pokemon)) {
            Zapdos.recibirMedicina(medicina);
        }
        if ("Moltres".equals(pokemon)) {
            Moltres.recibirMedicina(medicina);
        }
        if ("Dratini".equals(pokemon)) {
            Dratini.recibirMedicina(medicina);
        }
        if ("Dragonair".equals(pokemon)) {
            Dragonair.recibirMedicina(medicina);
        }
        if ("Dragonite".equals(pokemon)) {
            Dragonite.recibirMedicina(medicina);
        }
        if ("Mewtwo".equals(pokemon)) {
            Mewtwo.recibirMedicina(medicina);
        }
        if ("Mew".equals(pokemon)) {
            Mew.recibirMedicina(medicina);
        }
    }
    
    private int obtenerNumeroCompra() {
        return Integer.valueOf(NumeroDeCompra.getText());
    }
    
    private int obtenerNumeroPokemon() {
        return Integer.valueOf(NumeroPokemon.getText());
    }
    
    protected int darVuelto() {
        return dinero;
    }
    /**
     * @param args the command line arguments
     */

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Comprar;
    private javax.swing.JButton DarMedicina;
    private javax.swing.JTextField NumeroDeCompra;
    private javax.swing.JTextField NumeroPokemon;
    private javax.swing.JLabel PreguntarCualPokemon;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    // End of variables declaration//GEN-END:variables
}
