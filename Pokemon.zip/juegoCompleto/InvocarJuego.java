/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.pokemonsjuego.juegoCompleto;

import com.mycompany.pokemonsjuego.juegoCompleto.frameYPngs.PokemonGo;
/**
 *
 * @author DELL
 */
public class InvocarJuego {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        PokemonGo abrir = new PokemonGo();
        abrir.setVisible(true);
    }
    
}
